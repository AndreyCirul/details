﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;

namespace deteils
{
    class element
    {

        public string type;
        public string name;
        public element perent;
        public List<element> children = new List<element>();
        public int posX;
        public int posY;
        public int durability;
        public int timeWork;
        public bool workedOut = false;
        public Panel card;
        private Label text1;
        private Label text2;
        private Label text3;
        private Label additionText;
        public Label engineSpeedL;
        public Label errorMes;
        public Label maxTimeL;
        public Label timeWorkedL;
        public ComboBox typeBox;
        public ComboBox winchSpeed;
        public TrackBar engineSpeed;
        public TextBox volt;
        public TextBox timeWorked;
        public Button add;
        public Button delete;
        private List<type> types;
        private List<element> elements;
        private Panel workPlace;
        public Button changeB;
        public Button analise;
        public float testTime = 0f;
        public Label typeL;
        private string loadType;
        private int enginesCount = 0;
        public int timeAfterWorkOut = 0;
        public int maxV = 0;
        public int timer = 0;
        public bool engineDamaged = false;
        public bool enginePistone = false;
        private string connectionString;

        public element(string connectionString, List<type> types, Panel workPlace, List<element> elements, string runType)
        {
            loadType = runType;
            this.types = types;
            this.elements = elements;
            this.workPlace = workPlace;
            this.connectionString = connectionString;

            #region card

            card = new Panel();

            posX = 10;
            posY = 10;
            card.Location = new System.Drawing.Point(posX, posY);
            card.Size = new Size(262, 200);
            card.BackColor = Color.WhiteSmoke;
            card.BorderStyle = BorderStyle.FixedSingle;

            workPlace.Controls.Add(card);
            #endregion

            #region text1 

            text1 = new Label();

            text1.Name = "text1";
            text1.Location = new Point(7, 29);
            text1.Text = "Тип";
            text1.AutoSize = true;

            card.Controls.Add(text1);

            #endregion

            #region text2 

            text2 = new Label();

            text2.Name = "text2";
            text2.Location = new Point(7, 49);
            text2.Text = "Время эксплуатации";
            text2.AutoSize = true;

            card.Controls.Add(text2);

            #endregion

            #region winchSpeed
            winchSpeed = new ComboBox();
            winchSpeed.Name = "winchSpeed";
            winchSpeed.Items.Add("медленно 12 об\\м - 326 кг\\с");
            winchSpeed.Items.Add("нормально 110 об\\м - 1440 кг\\с");
            winchSpeed.Location = new Point(10, 100);
            winchSpeed.Size = new Size(150, 15);

            ToolTip wincTip = new ToolTip();
            wincTip.SetToolTip(winchSpeed, "Скорость лебедки");

            #endregion

            #region engineSpeed
            engineSpeed = new TrackBar();
            engineSpeed.Name = "engineSpeed";
            engineSpeed.Minimum = 100;
            engineSpeed.Maximum = 10000;
            engineSpeed.Location = new Point(5, 100);
            engineSpeed.Size = new Size(250, 15);
            engineSpeed.Scroll += engineSpeed_Scroll;

            ToolTip engineTip = new ToolTip();
            engineTip.SetToolTip(engineSpeed, "Обороты двигателя");
            #endregion

            #region volt
            volt = new TextBox();
            volt.Name = "volt";
            volt.Text = "1";
            volt.Location = new Point(10, 100);
            volt.Size = new Size(150, 15);
            volt.KeyPress += volt_KeyPress;
            volt.Leave += volt_Leave;

            ToolTip voltTip = new ToolTip();
            voltTip.SetToolTip(volt, "Вольт");
            #endregion

            if (runType == "create")
            {
                #region text2 

                text2 = new Label();

                text2.Name = "text2";
                text2.Location = new Point(7, 49);
                text2.Text = "Время эксплуатации";
                text2.AutoSize = true;

                card.Controls.Add(text2);

                #endregion

                #region text3 

                text3 = new Label();

                text3.Name = "text3";
                text3.Location = new Point(7, 143);
                text3.Text = "Срок эксплуатации";
                text3.AutoSize = true;

                card.Controls.Add(text3);

                #endregion

                #region maxTimeL 

                maxTimeL = new Label();

                maxTimeL.Name = "maxTimeL";
                maxTimeL.Location = new Point(118, 143);
                maxTimeL.Text = "0";
                maxTimeL.AutoSize = true;

                card.Controls.Add(maxTimeL);

                #endregion

                #region typeBox

                typeBox = new ComboBox();
                typeBox.Name = "typeBox";
                typeBox.Location = new Point(39, 26);
                typeBox.Size = new Size(216, 21);

                foreach (type t in types)
                {
                    if (t.name != types[0].name && t.name != types[2].name && t.name != types[8].name && t.name != types[9].name && t.name != types[10].name && t.name != types[11].name && !t.used)
                    {
                        typeBox.Items.Add(t.name);
                    }
                }

                typeBox.SelectedIndexChanged += typeChanged;

                card.Controls.Add(typeBox);

                #endregion

                #region timeWorked

                timeWorked = new TextBox();
                timeWorked.Name = "timeWorkted";
                timeWorked.Location = new Point(7, 65);
                timeWorked.Size = new Size(100, 20);
                timeWorked.Text = "0";
                timeWorked.KeyPress += timeOnlyNum;
                timeWorked.Leave += timeChangedEnd;

                card.Controls.Add(timeWorked);
                #endregion

                #region add

                add = new Button();
                add.Name = "add";
                add.Location = new Point(180, 170);
                add.Text = "Добавить";
                add.BackColor = Color.WhiteSmoke;
                add.Click += add_click;

                card.Controls.Add(add);
                add.Hide();
                #endregion

                #region additionText
                additionText = new Label();
                additionText.Name = "additionText";
                additionText.Location = new Point(7, 85);
                additionText.Size = new Size(100, 20);
                additionText.AutoSize = true;

                card.Controls.Add(additionText);
                #endregion         

                #region engineSpeedL
                engineSpeedL = new Label();
                engineSpeedL.Name = "engineSpeedL";
                engineSpeedL.Text = "100 оборотов в минуту";
                engineSpeedL.Location = new Point(130, 85);
                engineSpeedL.Size = new Size(100, 20);
                engineSpeedL.AutoSize = true;
                #endregion

            }
            else
            {
                card.Size = new Size(295, 115);

                text2.Text = "Процентный коэффициент времени работы системы";

                #region typeL
                typeL = new Label();
                typeL.Name = "typeL";
                typeL.Location = new Point(39, 28);
                typeL.Size = new Size(216, 21);

                card.Controls.Add(typeL);
                #endregion

                #region timeWorkedL
                timeWorkedL = new Label();
                timeWorkedL.Name = "timeWorkedL";
                timeWorkedL.Location = new Point(125, 65);
                timeWorkedL.AutoSize = true;


                card.Controls.Add(timeWorkedL);
                #endregion                              

                #region changeB

                changeB = new Button();
                changeB.Name = "changeB";
                changeB.Location = new Point(3, 85);
                changeB.Text = "Заменить";
                changeB.BackColor = Color.WhiteSmoke;
                changeB.Click += changeB_click;

                card.Controls.Add(changeB);
                #endregion

                #region errorMes

                errorMes = new Label();
                errorMes.Name = "errorMes";
                errorMes.Location = new Point(5, 5);
                errorMes.AutoSize = true;
                errorMes.ForeColor = Color.Red;

                card.Controls.Add(errorMes);

                #endregion

                #region analise

                analise = new Button();
                analise.Name = "analise";
                analise.Location = new Point(80, 85);
                analise.Text = "Анализ остаточного времени работы";
                analise.BackColor = Color.WhiteSmoke;
                analise.AutoSize = true;
                analise.Click += Analise_Click;
                card.Controls.Add(analise);

                #endregion
            }
        }

        public element(string connectionString, List<type> types, Panel workPlace, List<element> elements, element perent, string runType, int enginesCount)
        {
            loadType = runType;
            this.types = types;
            this.elements = elements;
            this.workPlace = workPlace;
            this.enginesCount = enginesCount;
            this.connectionString = connectionString;
            workPlace.Paint += drowLines;

            this.perent = perent;

            #region card

            card = new Panel();
            card.Name = "card";
            card.Size = new Size(262, 200);
            card.BackColor = Color.WhiteSmoke;
            card.BorderStyle = BorderStyle.FixedSingle;
            workPlace.Controls.Add(card);

            #endregion

            #region text1 

            text1 = new Label();
            text1.Name = "text1";
            text1.Location = new Point(7, 29);
            text1.Text = "Тип";
            text1.AutoSize = true;

            card.Controls.Add(text1);

            #endregion

            #region text2 

            text2 = new Label();

            text2.Name = "text2";
            text2.Location = new Point(7, 49);
            text2.Text = "Время эксплуатации";
            text2.AutoSize = true;

            card.Controls.Add(text2);

            #endregion

            #region winchSpeed
            winchSpeed = new ComboBox();
            winchSpeed.Name = "winchSpeed";
            winchSpeed.Items.Add("медленно 12 об\\м - 326 кг\\с");
            winchSpeed.Items.Add("нормально 110 об\\м - 1440 кг\\с");
            winchSpeed.Location = new Point(10, 100);
            winchSpeed.Size = new Size(150, 15);

            ToolTip wincTip = new ToolTip();
            wincTip.SetToolTip(winchSpeed, "Скорость лебедки");

            #endregion

            #region engineSpeed
            engineSpeed = new TrackBar();
            engineSpeed.Name = "engineSpeed";
            engineSpeed.Minimum = 100;
            engineSpeed.Maximum = 10000;
            engineSpeed.Location = new Point(5, 100);
            engineSpeed.Size = new Size(250, 15);
            engineSpeed.Scroll += engineSpeed_Scroll;

            ToolTip engineTip = new ToolTip();
            engineTip.SetToolTip(engineSpeed, "Обороты двигателя");
            #endregion

            #region volt
            volt = new TextBox();
            volt.Name = "volt";
            volt.Text = "1";
            volt.Location = new Point(10, 100);
            volt.Size = new Size(150, 15);
            volt.KeyPress += volt_KeyPress;
            volt.Leave += volt_Leave;

            ToolTip voltTip = new ToolTip();
            voltTip.SetToolTip(volt, "Вольт");
            #endregion

            if (runType == "create")
            {

                #region text3 

                text3 = new Label();

                text3.Name = "text3";
                text3.Location = new Point(7, 143);
                text3.Text = "Срок эксплуатации";
                text3.AutoSize = true;

                card.Controls.Add(text3);

                #endregion

                #region maxTimeL 

                maxTimeL = new Label();

                maxTimeL.Name = "maxTimeL";
                maxTimeL.Location = new Point(118, 143);
                maxTimeL.Text = "0";
                maxTimeL.AutoSize = true;

                card.Controls.Add(maxTimeL);

                #endregion

                #region typeBox

                typeBox = new ComboBox();
                typeBox.Name = "typeBox";
                typeBox.Location = new Point(39, 26);
                typeBox.Size = new Size(216, 21);



                foreach (type t in types)
                {
                    if (t.name != types[0].name && t.name != types[2].name && t.name != types[8].name && t.name != types[9].name && t.name != types[10].name && t.name != types[11].name && !t.used)
                    {
                        typeBox.Items.Add(t.name);
                    }
                }
                if (perent.type == types[6].name || perent.type == types[7].name)
                {
                    bool t1 = true;
                    bool t2 = true;
                    bool t3 = true;


                    foreach (element el in perent.children)
                    {
                        if (el.typeBox.SelectedItem != null)
                        {
                            if (el.typeBox.SelectedItem.ToString() == types[0].name)
                                t1 = false;
                            if (el.typeBox.SelectedItem.ToString() == types[8].name)
                                t2 = false;
                            if (el.typeBox.SelectedItem.ToString() == types[9].name)
                                t3 = false;
                        }
                    }

                    if (t1)
                        typeBox.Items.Add(types[0].name);
                    if (t2)
                        typeBox.Items.Add(types[8].name);
                    if (t3)
                        typeBox.Items.Add(types[9].name);
                }
                if (perent.type == types[14].name)
                {
                    bool t1 = true;
                    bool t2 = true;

                    foreach (element el in perent.children)
                    {
                        if (el.typeBox.SelectedItem != null)
                        {
                            if (el.typeBox.SelectedItem.ToString() == types[2].name)
                                t1 = false;
                            if (el.typeBox.SelectedItem.ToString() == types[11].name)
                                t2 = false;
                        }
                    }
                    if (t1)
                        typeBox.Items.Add(types[2].name);
                    if (t2)
                        typeBox.Items.Add(types[11].name);
                }
                if (perent.type == types[13].name)
                {
                    bool t1 = true;

                    foreach (element el in perent.children)
                    {
                        if (el.typeBox.SelectedItem != null)
                        {
                            if (el.typeBox.SelectedItem.ToString() == types[10].name)
                                t1 = false;
                        }
                    }

                    if (t1)
                        typeBox.Items.Add(types[10].name);
                }


                typeBox.SelectedIndexChanged += typeChanged;

                card.Controls.Add(typeBox);

                #endregion

                #region timeWorked

                timeWorked = new TextBox();
                timeWorked.Name = "timeWorkted";
                timeWorked.Location = new Point(7, 65);
                timeWorked.Size = new Size(100, 20);
                timeWorked.Text = "0";
                timeWorked.KeyPress += timeOnlyNum;
                timeWorked.Leave += timeChangedEnd;

                card.Controls.Add(timeWorked);
                #endregion

                #region add

                add = new Button();
                add.Name = "add";
                add.Location = new Point(180, 170);
                add.Text = "Добавить";
                add.BackColor = Color.WhiteSmoke;
                add.Click += add_click;

                card.Controls.Add(add);
                add.Hide();
                #endregion

                #region delete

                delete = new Button();
                delete.Name = "delete";
                delete.Location = new Point(3, 170);
                delete.Text = "Убрать";
                delete.BackColor = Color.WhiteSmoke;
                delete.Click += delete_click;

                card.Controls.Add(delete);
                #endregion

                #region additionText
                additionText = new Label();
                additionText.Name = "additionText";
                additionText.Location = new Point(7, 85);
                additionText.Size = new Size(100, 20);
                additionText.AutoSize = true;

                card.Controls.Add(additionText);

                #endregion

                #region engineSpeedL
                engineSpeedL = new Label();
                engineSpeedL.Name = "engineSpeedL";
                engineSpeedL.Text = "100 оборотов в минуту";
                engineSpeedL.Location = new Point(130, 85);
                engineSpeedL.Size = new Size(100, 20);
                engineSpeedL.AutoSize = true;
                #endregion       

            }
            else
            {
                card.Size = new Size(295, 115);

                text2.Text = "Процентный коэффициент времени работы системы";

                #region typeL
                typeL = new Label();
                typeL.Name = "typeL";
                typeL.Location = new Point(39, 28);
                typeL.Size = new Size(121, 21);
                typeL.AutoSize = true;

                card.Controls.Add(typeL);
                #endregion

                # region timeWorkedL
                timeWorkedL = new Label();
                timeWorkedL.Name = "timeWorkedL";
                timeWorkedL.Location = new Point(125, 65);
                timeWorkedL.AutoSize = true;

                card.Controls.Add(timeWorkedL);
                #endregion                               

                #region changeB

                changeB = new Button();
                changeB.Name = "changeB";
                changeB.Location = new Point(3, 85);
                changeB.Text = "Заменить";
                changeB.BackColor = Color.WhiteSmoke;
                changeB.Click += changeB_click;

                card.Controls.Add(changeB);
                #endregion               

                #region errorMes

                errorMes = new Label();
                errorMes.Name = "errorMes";
                errorMes.Location = new Point(5, 5);
                errorMes.AutoSize = true;

                card.Controls.Add(errorMes);

                #endregion

                #region analise

                analise = new Button();
                analise.Name = "analise";
                analise.Location = new Point(80, 85);
                analise.Text = "Анализ остаточного времени работы";
                analise.BackColor = Color.WhiteSmoke;
                analise.AutoSize = true;
                analise.Click += Analise_Click;
                card.Controls.Add(analise);

                #endregion

            }
        }

        private void Analise_Click(object sender, EventArgs e)
        {
            if ((durability - testTime)>0)
                MessageBox.Show("Осталось " + (durability - testTime).ToString() + " часов");
            else
                MessageBox.Show("Осталось 0 часов");
        }

        private void engineSpeed_Scroll(object sender, EventArgs e)
        {
            engineSpeedL.Text = engineSpeed.Value.ToString() + " оборотов в минуту";
        }

        public void addEngineSpeed()
        {
            engineSpeed.Enabled = true;
            additionText.Text = "Скорость";
            card.Controls.Add(engineSpeedL);
            card.Controls.Add(engineSpeed);
        }

        public void addWinchSpeed()
        {
            winchSpeed.Enabled = true;
            additionText.Text = "Обороты в минуту";
            card.Controls.Add(winchSpeed);
            winchSpeed.SelectedIndex = 0;
        }

        public void addVolt()
        {
            volt.Enabled = true;
            additionText.Text = "Напряжение";
            card.Controls.Add(volt);
        }

        private void volt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar))
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void volt_Leave(object sender, EventArgs e)
        {
            if (Convert.ToInt32(volt.Text) < 1)
            {
                volt.Text = "1";
            }
        }

        private void typeChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < types.Count; i++)
            {
                if (types[i].name == typeBox.SelectedItem.ToString())
                {
                    type = types[i].name;
                    durability = types[i].maxTime;
                    maxTimeL.Text = durability.ToString();
                }
            }

            foreach (type type in types)
            {
                type.used = false;
            }

            int a = 0;
            foreach (element el in elements)
            {
                a++;
                int b = 0;
                foreach (type type in types)
                {
                    b++;
                    if (el.typeBox.SelectedItem != null)
                    {
                        if (el.typeBox.SelectedItem.ToString() == type.name)
                        {
                            type.used = true;
                        }
                    }
                }
            }

            if (typeBox.SelectedItem.ToString() != types[0].name && typeBox.SelectedItem.ToString() != types[2].name && typeBox.SelectedItem.ToString() != types[8].name && typeBox.SelectedItem.ToString() != types[9].name && typeBox.SelectedItem.ToString() != types[10].name && typeBox.SelectedItem.ToString() != types[11].name)
            {
                add.Show();
            }
            else
            {
                add.Hide();
            }

            if (typeBox.SelectedItem.ToString() == types[6].name || typeBox.SelectedItem.ToString() == types[7].name)
            {
                addEngineSpeed();
            }
            else
            {
                if (engineSpeed.Enabled)
                {
                    engineSpeed.Enabled = false;
                    if (typeBox.SelectedItem.ToString() != types[12].name && typeBox.SelectedItem.ToString() != types[14].name)
                        additionText.Text = "";
                    card.Controls.Remove(engineSpeedL);
                    card.Controls.Remove(engineSpeed);
                }
            }

            if (typeBox.SelectedItem.ToString() == types[12].name)
            {
                addWinchSpeed();
            }
            else
            {
                if (winchSpeed.Enabled)
                {
                    winchSpeed.Enabled = false;
                    if (typeBox.SelectedItem.ToString() != types[6].name && typeBox.SelectedItem.ToString() != types[7].name && typeBox.SelectedItem.ToString() != types[14].name)
                        additionText.Text = "";
                    card.Controls.Remove(winchSpeed);
                }
            }

            if (typeBox.SelectedItem.ToString() == types[14].name)
            {
                addVolt();
            }
            else
            {
                if (volt.Enabled)
                {
                    volt.Enabled = false;
                    if (typeBox.SelectedItem.ToString() != types[6].name && typeBox.SelectedItem.ToString() != types[7].name && typeBox.SelectedItem.ToString() != types[12].name)
                        additionText.Text = "";
                    card.Controls.Remove(volt);
                }
            }

            List<type> typeL = new List<type>();

            foreach (element el in elements)
            {
                typeL.Clear();

                foreach (type t in types)
                {
                    if (t.name != types[0].name && t.name != types[2].name && t.name != types[8].name && t.name != types[9].name && t.name != types[10].name && t.name != types[11].name)
                    {
                        typeL.Add(new type());
                        typeL[typeL.Count - 1] = t;
                    }
                }

                for (int i = el.typeBox.Items.Count - 1; i >= 0; i--)
                {
                    for (int j = typeL.Count - 1; j >= 0; j--)
                    {
                        if (el.typeBox.Items[i].ToString() == typeL[j].name)
                        {
                            if (!typeL[j].used)
                            {
                                typeL.RemoveAt(j);
                            }
                            else
                            {
                                if (el.typeBox.SelectedIndex != i)
                                {
                                    el.typeBox.Items.RemoveAt(i);
                                    break;
                                }
                                typeL.RemoveAt(j);
                            }
                        }

                    }
                }

                foreach (type t in typeL)
                {
                    if (!t.used)
                        el.typeBox.Items.Add(t.name);
                }
            }
            if (perent != null)
            {
                if (perent.type == types[6].name || perent.type == types[7].name)
                {
                    bool t1 = true;
                    bool t2 = true;
                    bool t3 = true;

                    foreach (element el in perent.children)
                    {
                        if (el.typeBox.SelectedItem != null)
                        {
                            if (el.typeBox.SelectedItem.ToString() == types[0].name)
                                t1 = false;
                            if (el.typeBox.SelectedItem.ToString() == types[8].name)
                                t2 = false;
                            if (el.typeBox.SelectedItem.ToString() == types[9].name)
                                t3 = false;
                        }
                    }

                    foreach (element el in perent.children)
                    {
                        bool t1Ex = true;
                        bool t2Ex = true;
                        bool t3Ex = true;

                        for (int i = el.typeBox.Items.Count - 1; i >= 0; i--)
                        {
                            if (el.typeBox.Items[i].ToString() == types[0].name)
                            {
                                if (!t1)
                                {
                                    if (el.typeBox.SelectedItem != null)
                                    {
                                        if (el.typeBox.SelectedItem.ToString() != types[0].name)
                                        {
                                            el.typeBox.Items.RemoveAt(i);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        el.typeBox.Items.RemoveAt(i);
                                        break;
                                    }
                                }
                                else
                                {
                                    t1Ex = false;
                                }
                            }
                            if (el.typeBox.Items[i].ToString() == types[8].name)
                            {
                                if (!t2)
                                {
                                    if (el.typeBox.SelectedItem != null)
                                    {

                                        if (el.typeBox.SelectedItem.ToString() != types[8].name)
                                        {
                                            el.typeBox.Items.RemoveAt(i);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        el.typeBox.Items.RemoveAt(i);
                                        break;
                                    }
                                }
                                else
                                {
                                    t2Ex = false;
                                }
                            }
                            if (el.typeBox.Items[i].ToString() == types[9].name)
                            {
                                if (!t3)
                                {
                                    if (el.typeBox.SelectedItem != null)
                                    {
                                        if (el.typeBox.SelectedItem.ToString() != types[9].name)
                                        {
                                            el.typeBox.Items.RemoveAt(i);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        el.typeBox.Items.RemoveAt(i);
                                        break;
                                    }
                                }
                                else
                                {
                                    t3Ex = false;
                                }
                            }
                        }

                        if (t1)
                        {
                            if (t1Ex)
                            {
                                el.typeBox.Items.Add(types[0].name);
                            }
                        }
                        if (t2)
                        {
                            if (t2Ex)
                            {
                                el.typeBox.Items.Add(types[8].name);
                            }
                        }
                        if (t3)
                        {
                            if (t3Ex)
                            {
                                el.typeBox.Items.Add(types[9].name);
                            }
                        }
                    }
                }
                if (perent.type == types[13].name)
                {
                    bool t1 = true;
                    bool t2 = true;

                    foreach (element el in perent.children)
                    {
                        if (el.typeBox.SelectedItem != null)
                        {
                            if (el.typeBox.SelectedItem.ToString() == types[2].name)
                                t1 = false;
                            if (el.typeBox.SelectedItem.ToString() == types[11].name)
                                t2 = false;                           
                        }
                    }

                    foreach (element el in perent.children)
                    {
                        bool t1Ex = true;
                        bool t2Ex = true;                       

                        for (int i = el.typeBox.Items.Count - 1; i >= 0; i--)
                        {
                            if (el.typeBox.Items[i].ToString() == types[2].name)
                            {
                                if (!t1)
                                {
                                    if (el.typeBox.SelectedItem != null)
                                    {
                                        if (el.typeBox.SelectedItem.ToString() != types[2].name)
                                        {
                                            el.typeBox.Items.RemoveAt(i);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        el.typeBox.Items.RemoveAt(i);
                                        break;
                                    }
                                }
                                else
                                {
                                    t1Ex = false;
                                }
                            }
                            if (el.typeBox.Items[i].ToString() == types[11].name)
                            {
                                if (!t2)
                                {
                                    if (el.typeBox.SelectedItem != null)
                                    {

                                        if (el.typeBox.SelectedItem.ToString() != types[11].name)
                                        {
                                            el.typeBox.Items.RemoveAt(i);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        el.typeBox.Items.RemoveAt(i);
                                        break;
                                    }
                                }
                                else
                                {
                                    t2Ex = false;
                                }
                            }                       
                        }

                        if (t1)
                        {
                            if (t1Ex)
                            {
                                el.typeBox.Items.Add(types[2].name);
                            }
                        }
                        if (t2)
                        {
                            if (t2Ex)
                            {
                                el.typeBox.Items.Add(types[11].name);
                            }
                        }                       
                    }
                }
                if (perent.type == types[14].name)
                {
                    bool t1 = true;
                    

                    foreach (element el in perent.children)
                    {
                        if (el.typeBox.SelectedItem != null)
                        {
                            if (el.typeBox.SelectedItem.ToString() == types[10].name)
                                t1 = false;                          
                        }
                    }

                    foreach (element el in perent.children)
                    {
                        bool t1Ex = true;

                        for (int i = el.typeBox.Items.Count - 1; i >= 0; i--)
                        {
                            if (el.typeBox.Items[i].ToString() == types[10].name)
                            {
                                if (!t1)
                                {
                                    if (el.typeBox.SelectedItem != null)
                                    {
                                        if (el.typeBox.SelectedItem.ToString() != types[10].name)
                                        {
                                            el.typeBox.Items.RemoveAt(i);
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        el.typeBox.Items.RemoveAt(i);
                                        break;
                                    }
                                }
                                else
                                {
                                    t1Ex = false;
                                }
                            }                          
                        }

                        if (t1)
                        {
                            if (t1Ex)
                            {
                                el.typeBox.Items.Add(types[10].name);
                            }
                        }                        
                    }
                }
            }

            foreach (element el in elements)
            {
                if (el.typeBox.SelectedItem != null)
                {
                    if (el.typeBox.SelectedItem.ToString() == types[6].name || el.typeBox.SelectedItem.ToString() == types[7].name)
                    {
                        int det = 0;

                        foreach (element ch in children)
                        {
                            if (ch.typeBox.SelectedItem.ToString() == types[0].name && ch.typeBox.SelectedItem.ToString() == types[8].name && ch.typeBox.SelectedItem.ToString() == types[9].name)
                            {
                                det++;
                            }
                        }

                        if (el.typeBox.Items.Count == 1 && det == 3)
                        {
                            el.add.Hide();
                        }
                        else
                        {
                            el.add.Show();
                        }
                    }
                    else
                    {
                        if (el.typeBox.SelectedItem.ToString() == types[13].name)
                        {
                            int det = 0;

                            foreach (element ch in children)
                            {
                                if (ch.typeBox.SelectedItem.ToString() == types[2].name && ch.typeBox.SelectedItem.ToString() == types[11].name)
                                {
                                    det++;
                                }
                            }

                            if (el.typeBox.Items.Count == 1 && det == 2)
                            {
                                el.add.Hide();
                            }
                            else
                            {
                                el.add.Show();
                            }
                        }
                        else
                        {
                            if (el.typeBox.SelectedItem.ToString() == types[14].name)
                            {
                                int det = 0;

                                foreach (element ch in children)
                                {
                                    if (ch.typeBox.SelectedItem.ToString() == types[10].name)
                                    {
                                        det++;
                                    }
                                }

                                if (el.typeBox.Items.Count == 1 && det == 1)
                                {
                                    el.add.Hide();
                                }
                                else
                                {
                                    el.add.Show();
                                }
                            }
                            else
                            {
                                if (el.typeBox.Items.Count > 1 && el.typeBox.SelectedItem.ToString() != types[0].name && el.typeBox.SelectedItem.ToString() != types[8].name && el.typeBox.SelectedItem.ToString() != types[9].name && el.typeBox.SelectedItem.ToString() != types[2].name && el.typeBox.SelectedItem.ToString() != types[11].name && el.typeBox.SelectedItem.ToString() != types[10].name)
                                {
                                    el.add.Show();
                                }
                                else
                                {
                                    el.add.Hide();
                                }
                            }
                        }
                    }

                }
            }

            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from usedDetails", con);
            DataTable used = new DataTable();
            con.Open();
            da.Fill(used);
            for(int i=0; i<used.Rows.Count; i++)
            {
                if(used.Rows[i][1].ToString()==type)
                {
                    durability = Convert.ToInt32(used.Rows[i][2]);
                    maxTimeL.Text = durability.ToString();
                }
            }
            con.Close();
        }

        private void add_click(object sender, EventArgs e)
        {
            for (int i = 0; i < elements.Count; i++)
                if (elements[i] == this)
                {
                    elements.Add(new element(connectionString ,types, workPlace, elements, elements[i], "create", enginesCount));
                    elements[i].children.Add(elements[elements.Count - 1]);
                    replace();
                }

            foreach (element el in elements)
            {
                if (el.children.Count > 0)
                {
                    el.typeBox.Enabled = false;

                }
                else
                {
                    el.typeBox.Enabled = true;

                }
            }
        }

        private void delete_click(object sender, EventArgs e)
        {
            List<element> forDelete = new List<element>();
            for (int i = 0; i < elements.Count; i++)
            {
                if (elements[i] == this)
                {
                    forDelete.Add(elements[i]);
                    break;
                }
            }

            for (int i = 0; i < forDelete.Count; i++)
            {
                for (int j = 0; j < forDelete[i].children.Count; j++)
                {
                    for (int k = 0; k < elements.Count; k++)
                    {
                        if (forDelete[i].children[j] == elements[k])
                        {
                            forDelete.Add(elements[k]);
                        }
                    }
                }
            }

            while (forDelete.Count > 0)
            {
                for (int i = 0; i < elements.Count; i++)
                {
                    if (elements[i] == forDelete[forDelete.Count - 1])
                    {
                        for (int j = 0; j < elements[i].perent.children.Count; j++)
                        {
                            if (elements[i].perent.children[j] == elements[i])
                            {
                                elements[i].perent.children.RemoveAt(j);
                            }
                        }
                        workPlace.Controls.Remove(elements[i].card);
                        elements.RemoveAt(i);
                        forDelete.RemoveAt(forDelete.Count - 1);

                        replace();
                        break;
                    }
                }
            }

            foreach (element el in elements)
            {
                if (el.children.Count > 0)
                {
                    el.typeBox.Enabled = false;

                }
                else
                {
                    el.typeBox.Enabled = true;

                }
            }
        }

        public void replace()
        {
            for (int i = 0; i < elements.Count; i++)
            {
                if (elements[i].perent != null)
                {
                    if (elements[i].perent.children.Count == 1)
                    {
                        elements[i].card.Location = new Point(elements[i].perent.card.Location.X, elements[i].perent.card.Location.Y + elements[i].card.Size.Height + 30);
                    }
                    else
                    {
                        List<element> count = new List<element>();

                        for (int k = 0; k < elements[i].perent.children.Count; k++)
                        {
                            if (elements[i].perent.children[k] != elements[i])
                            {
                                count.Add(elements[i].perent.children[k]);
                            }
                            else
                            {
                                break;
                            }
                        }

                        int x = 0;
                        while (count.Count != 0)
                        {
                            if (count[0].children.Count != 0)
                            {
                                for (int k = 0; k < count[0].children.Count; k++)
                                {

                                    count.Add(count[0].children[k]);
                                }
                                count.RemoveAt(0);
                            }
                            else
                            {
                                count.RemoveAt(0);
                                x++;
                            }
                        }

                        elements[i].card.Location = new Point(elements[i].perent.card.Location.X + (elements[i].card.Size.Width + 20) * (x), elements[i].perent.card.Location.Y + elements[i].card.Size.Height + 30);
                    }
                }
            }

            int maxY = 0;
            int maxX = 0;
            for (int i = 0; i < elements.Count; i++)
            {
                if (elements[i].card.Location.X > maxX)
                    maxX = elements[i].card.Location.X;
                if (elements[i].card.Location.Y > maxY)
                    maxY = elements[i].card.Location.Y;
            }

            workPlace.Size = new Size(maxX + 232, maxY + 188 + 5);

            workPlace.Refresh();
        }

        public void drowLines(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(Color.White);
            for (int i = 0; i < elements.Count; i++)
            {
                for (int j = 0; j < elements[i].children.Count; j++)
                {
                    Pen pen;
                    if (!elements[i].children[j].workedOut)
                    {
                        pen = new Pen(Color.Black);
                        e.Graphics.DrawLine(pen, elements[i].card.Location.X + elements[i].card.Size.Width / 2, elements[i].card.Location.Y + elements[i].card.Size.Height, elements[i].card.Location.X + elements[i].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10);
                        e.Graphics.DrawLine(pen, elements[i].card.Location.X + elements[i].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10, elements[i].children[j].card.Location.X + elements[i].children[j].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10);
                        e.Graphics.DrawLine(pen, elements[i].children[j].card.Location.X + elements[i].children[j].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10, elements[i].children[j].card.Location.X + elements[i].children[j].card.Size.Width / 2, elements[i].children[j].card.Location.Y);
                    }
                }
            }
            for (int i = 0; i < elements.Count; i++)
            {
                Pen pen;
                for (int j = 0; j < elements[i].children.Count; j++)
                {

                    if (elements[i].children[j].workedOut)
                    {
                        pen = new Pen(Color.Red);
                        e.Graphics.DrawLine(pen, elements[i].card.Location.X + elements[i].card.Size.Width / 2, elements[i].card.Location.Y + elements[i].card.Size.Height, elements[i].card.Location.X + elements[i].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10);
                        e.Graphics.DrawLine(pen, elements[i].card.Location.X + elements[i].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10, elements[i].children[j].card.Location.X + elements[i].children[j].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10);
                        e.Graphics.DrawLine(pen, elements[i].children[j].card.Location.X + elements[i].children[j].card.Size.Width / 2, elements[i].children[j].card.Location.Y - 10, elements[i].children[j].card.Location.X + elements[i].children[j].card.Size.Width / 2, elements[i].children[j].card.Location.Y);
                    }
                }
                if (elements[i].testTime >= elements[i].durability && elements[i].loadType != "create")
                {
                    pen = new Pen(Color.Red);
                    e.Graphics.DrawRectangle(pen, elements[i].card.Location.X - 1, elements[i].card.Location.Y - 1, elements[i].card.Width + 1, elements[i].card.Height + 1);
                }
            }
        }

        private void timeChangedEnd(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(timeWorked.Text);
            int max = Convert.ToInt32(maxTimeL.Text);
            if (num > max)
            {
                num = max;
                timeWorked.Text = num.ToString();
            }
            timeWork = num;

            foreach (element el in elements)
            {
                if (el.type == types[0].name)
                {
                    if (Convert.ToInt32(el.timeWorked.Text) > Convert.ToInt32(el.perent.timeWorked.Text))
                    {
                        el.timeWorked.Text = el.perent.timeWorked.Text;
                    }
                }

                if (el.type == types[2].name)
                {
                    if (Convert.ToInt32(el.timeWorked.Text) > Convert.ToInt32(el.perent.timeWorked.Text))
                    {
                        el.timeWorked.Text = el.perent.timeWorked.Text;
                    }
                }

                if (el.type == types[8].name)
                {
                    if (Convert.ToInt32(el.timeWorked.Text) > Convert.ToInt32(el.perent.timeWorked.Text))
                    {
                        el.timeWorked.Text = el.perent.timeWorked.Text;
                    }
                }

                if (el.type == types[9].name)
                {
                    if (Convert.ToInt32(el.timeWorked.Text) > Convert.ToInt32(el.perent.timeWorked.Text))
                    {
                        el.timeWorked.Text = el.perent.timeWorked.Text;
                    }
                }

                if (el.type == types[10].name)
                {
                    if (Convert.ToInt32(el.timeWorked.Text) > Convert.ToInt32(el.perent.timeWorked.Text))
                    {
                        el.timeWorked.Text = el.perent.timeWorked.Text;
                    }
                }

                if (el.type == types[11].name)
                {
                    if (Convert.ToInt32(el.timeWorked.Text) > Convert.ToInt32(el.perent.timeWorked.Text))
                    {
                        el.timeWorked.Text = el.perent.timeWorked.Text;
                    }
                }
            }

        }

        private void timeOnlyNum(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar))
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void changeB_click(object sender, EventArgs e)
        {
            change();
        }

        public void change()
        {
            testTime = 0f;
            timeWorkedL.Text = "100%";
            workedOut = false;
            timeAfterWorkOut = 0;

            foreach (type t in types)
            {
                if (type == t.name)
                {
                    durability = t.maxTime;

                }
            }



            if (testTime >= durability)
            {
                workedOut = true;
            }
            else
            {

                if (typeL.Text == types[3].name)
                {
                    foreach (element element in elements)
                    {
                        if (element.typeL.Text == types[2].name || element.typeL.Text == types[11].name)
                        {
                            if (element.testTime < element.durability)
                                element.workedOut = false;
                        }
                    }
                }

                if (typeL.Text == types[4].name)
                {
                    foreach (element element in elements)
                    {
                        if (element.testTime < element.durability)
                            element.workedOut = false;
                        element.timeWorkedL.Show();
                        if (element.maxTimeL!=null)
                            element.maxTimeL.Show();
                        element.errorMes.Show();

                    }
                }

                if (typeL.Text == types[5].name)
                {
                    if (perent.testTime < perent.durability)
                        perent.workedOut = false;
                }

                if ((typeL.Text == types[6].name || typeL.Text == types[7].name))
                {
                    engineDamaged = false;
                    foreach (element element in elements)
                    {
                        if (element.testTime < element.durability)
                            element.workedOut = false;
                        element.timeWorkedL.Show();

                        element.errorMes.Show();

                    }

                }

                if (typeL.Text == types[8].name)
                {
                    perent.enginePistone = false;
                }

                if (typeL.Text == types[9].name)
                {
                    workedOut = false;
                }

                if (typeL.Text == types[10].name)
                {
                    if (perent.testTime < perent.durability)
                        perent.workedOut = false;
                }

                if (typeL.Text == types[11].name)
                {
                    if (perent.testTime < perent.durability)
                        perent.workedOut = false;
                }

                errorMes.Text = "";
            }

            int engines = 0;
            int workedOutEngines = 0;

            foreach (element el in elements)
            {

                if (el.type == types[6].name)
                {
                    engines++;
                }

                if (el.type == types[7].name)
                {
                    engines++;
                }


                if ((el.type == types[6].name || el.type == types[7].name) && el.workedOut)
                {
                    workedOutEngines++;
                }

                if (el.typeL.Text == types[3].name && el.workedOut)
                {
                    foreach (element element in elements)
                    {
                        if (element.typeL.Text == types[2].name || element.typeL.Text == types[11].name)
                        {
                            element.workedOut = true;
                        }
                    }
                }

                if (el.typeL.Text == types[4].name && el.workedOut)
                {
                    foreach (element element in elements)
                    {
                        element.workedOut = true;
                        element.timeWorkedL.Hide();
                        element.maxTimeL.Hide();
                        element.errorMes.Hide();

                    }
                }

                if (el.typeL.Text == types[5].name && el.workedOut)
                {
                    el.perent.workedOut = true;
                }

                if (el.typeL.Text == types[8].name && el.workedOut && !el.perent.enginePistone)
                {
                    el.perent.durability = el.perent.durability - (el.perent.durability / 100 * 30);
                    el.perent.enginePistone = true;
                }

                if (el.typeL.Text == types[9].name && el.perent.workedOut)
                {
                    el.workedOut = true;
                }

                if (el.typeL.Text == types[10].name && el.workedOut)
                {
                    el.perent.workedOut = true;
                }

                if (el.typeL.Text == types[11].name && el.workedOut)
                {
                    el.perent.workedOut = true;
                }
            }

            if (engines == enginesCount)
            {
                foreach (element element in elements)
                {
                    element.workedOut = true;
                    element.timeWorkedL.Hide();
                    element.maxTimeL.Hide();
                    element.errorMes.Hide();

                }
            }

            workPlace.Refresh();
        }
    }
}
