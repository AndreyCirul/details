﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace deteils
{
    public partial class statShow : Form
    {
        private main main;
        private DataTable stat = new DataTable();

        public statShow(main main)
        {
            InitializeComponent();

            this.main = main;

            this.Location = new Point(main.Location.X, main.Location.Y);
            SqlConnection con = new SqlConnection(main.connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            da.Fill(stat);
            statDG.DataSource = stat;
            con.Close();

            DateTime minDate = DateTime.Today;
            DateTime maxDate = DateTime.Today;

            for (int i = 0; i < stat.Rows.Count; i++)
            {
                if (minDate > Convert.ToDateTime(stat.Rows[i][3]))
                {
                    minDate = Convert.ToDateTime(stat.Rows[i][3]);
                    minDate =new DateTime(minDate.Year, minDate.Month, minDate.Day, 0,0,0);
                }
                if (minDate < Convert.ToDateTime(stat.Rows[i][3]))
                {
                    maxDate = Convert.ToDateTime(stat.Rows[i][3]);
                    maxDate = new DateTime(maxDate.Year, maxDate.Month, maxDate.Day, 23, 59, 59);
                }
            }

            minimumDate.MinDate = minDate;
            maximumDate.MinDate = minDate;
            minimumDate.Value = minDate;

            minimumDate.MaxDate = maxDate;
            maximumDate.MaxDate = maxDate;
            maximumDate.Value = maxDate;

            statDG.Columns[0].Visible = false;
            statDG.Columns[1].HeaderText = "Пользователь";
            statDG.Columns[2].HeaderText = "Действие";
            statDG.Columns[3].HeaderText = "Дата";
        }

        private void minimumDate_ValueChanged(object sender, EventArgs e)
        {
            maximumDate.MinDate = minimumDate.Value;

            for (int i = 0; i < stat.Rows.Count; i++)
            {
                statDG.CurrentCell = null;
                if (Convert.ToDateTime(stat.Rows[i][3]) < minimumDate.Value ||
                    Convert.ToDateTime(stat.Rows[i][3]) > maximumDate.Value)
                {
                    statDG.Rows[i].Visible = false;
                }
                else
                {
                    statDG.Rows[i].Visible = true;
                }
            }
        }

        private void maximumDate_ValueChanged(object sender, EventArgs e)
        {
            minimumDate.MaxDate = maximumDate.Value;

            for (int i = 0; i < stat.Rows.Count; i++)
            {
                statDG.CurrentCell = null;
                if (Convert.ToDateTime(stat.Rows[i][3]) < minimumDate.Value ||
                    Convert.ToDateTime(stat.Rows[i][3]) > maximumDate.Value)
                {
                    statDG.Rows[i].Visible = false;
                }
                else
                {
                    statDG.Rows[i].Visible = true;
                }
            }
        }

        private void Ok_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void statShow_FormClosed(object sender, FormClosedEventArgs e)
        {
            main.Show();
        }
    }
}
