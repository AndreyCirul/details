﻿namespace deteils
{
    partial class workWhisDb
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableDG = new System.Windows.Forms.DataGridView();
            this.Tables = new System.Windows.Forms.ComboBox();
            this.back = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tableDG)).BeginInit();
            this.SuspendLayout();
            // 
            // tableDG
            // 
            this.tableDG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableDG.Location = new System.Drawing.Point(2, 1);
            this.tableDG.Name = "tableDG";
            this.tableDG.Size = new System.Drawing.Size(452, 439);
            this.tableDG.TabIndex = 0;
            // 
            // Tables
            // 
            this.Tables.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Tables.FormattingEnabled = true;
            this.Tables.Items.AddRange(new object[] {
            "cards",
            "details",
            "Users",
            "statistic",
            "type"});
            this.Tables.Location = new System.Drawing.Point(460, 37);
            this.Tables.Name = "Tables";
            this.Tables.Size = new System.Drawing.Size(143, 21);
            this.Tables.TabIndex = 1;
            this.Tables.SelectedIndexChanged += new System.EventHandler(this.Tables_SelectedIndexChanged);
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.back.Location = new System.Drawing.Point(460, 408);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(143, 23);
            this.back.TabIndex = 2;
            this.back.Text = "Отменить";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // save
            // 
            this.save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.save.Location = new System.Drawing.Point(460, 379);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(143, 23);
            this.save.TabIndex = 3;
            this.save.Text = "Сохранить изменения";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(461, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Выбрать таблицу:";
            // 
            // workWhisDb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 443);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.save);
            this.Controls.Add(this.back);
            this.Controls.Add(this.Tables);
            this.Controls.Add(this.tableDG);
            this.MinimumSize = new System.Drawing.Size(418, 264);
            this.Name = "workWhisDb";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Таблицы базы данных";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.workWhisDb_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.tableDG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tableDG;
        private System.Windows.Forms.ComboBox Tables;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Label label1;
    }
}