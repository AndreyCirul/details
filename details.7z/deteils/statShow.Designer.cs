﻿namespace deteils
{
    partial class statShow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.maximumDate = new System.Windows.Forms.DateTimePicker();
            this.minimumDate = new System.Windows.Forms.DateTimePicker();
            this.statDG = new System.Windows.Forms.DataGridView();
            this.Ok = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statDG)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.maximumDate);
            this.panel1.Controls.Add(this.minimumDate);
            this.panel1.Location = new System.Drawing.Point(374, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(157, 93);
            this.panel1.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "До";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "От";
            // 
            // maximumDate
            // 
            this.maximumDate.Location = new System.Drawing.Point(3, 64);
            this.maximumDate.Name = "maximumDate";
            this.maximumDate.Size = new System.Drawing.Size(141, 20);
            this.maximumDate.TabIndex = 1;
            this.maximumDate.ValueChanged += new System.EventHandler(this.maximumDate_ValueChanged);
            // 
            // minimumDate
            // 
            this.minimumDate.Location = new System.Drawing.Point(3, 25);
            this.minimumDate.Name = "minimumDate";
            this.minimumDate.Size = new System.Drawing.Size(141, 20);
            this.minimumDate.TabIndex = 0;
            this.minimumDate.ValueChanged += new System.EventHandler(this.minimumDate_ValueChanged);
            // 
            // statDG
            // 
            this.statDG.AllowUserToAddRows = false;
            this.statDG.AllowUserToDeleteRows = false;
            this.statDG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.statDG.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.statDG.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.statDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.statDG.Location = new System.Drawing.Point(12, 12);
            this.statDG.Name = "statDG";
            this.statDG.ReadOnly = true;
            this.statDG.Size = new System.Drawing.Size(356, 292);
            this.statDG.TabIndex = 4;
            // 
            // Ok
            // 
            this.Ok.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Ok.Location = new System.Drawing.Point(240, 310);
            this.Ok.Name = "Ok";
            this.Ok.Size = new System.Drawing.Size(75, 23);
            this.Ok.TabIndex = 3;
            this.Ok.Text = "Ok";
            this.Ok.UseVisualStyleBackColor = true;
            this.Ok.Click += new System.EventHandler(this.Ok_Click);
            // 
            // statShow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 345);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statDG);
            this.Controls.Add(this.Ok);
            this.MinimumSize = new System.Drawing.Size(407, 248);
            this.Name = "statShow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Статистика";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.statShow_FormClosed);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statDG)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker maximumDate;
        private System.Windows.Forms.DateTimePicker minimumDate;
        private System.Windows.Forms.DataGridView statDG;
        private System.Windows.Forms.Button Ok;
    }
}