﻿namespace deteils
{
    partial class cardsTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.forPrint = new System.Windows.Forms.Panel();
            this.workField = new System.Windows.Forms.Panel();
            this.print = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.change = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.start = new System.Windows.Forms.Button();
            this.loadBox = new System.Windows.Forms.ComboBox();
            this.tempBar = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tempL = new System.Windows.Forms.Label();
            this.totalTimeL = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.forPrint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tempBar)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.forPrint);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(593, 456);
            this.panel1.TabIndex = 9;
            // 
            // forPrint
            // 
            this.forPrint.AutoSize = true;
            this.forPrint.BackColor = System.Drawing.Color.White;
            this.forPrint.Controls.Add(this.workField);
            this.forPrint.Location = new System.Drawing.Point(0, 0);
            this.forPrint.Name = "forPrint";
            this.forPrint.Size = new System.Drawing.Size(590, 448);
            this.forPrint.TabIndex = 0;
            // 
            // workField
            // 
            this.workField.AutoSize = true;
            this.workField.BackColor = System.Drawing.Color.White;
            this.workField.Location = new System.Drawing.Point(3, 3);
            this.workField.Name = "workField";
            this.workField.Size = new System.Drawing.Size(584, 442);
            this.workField.TabIndex = 0;
            // 
            // print
            // 
            this.print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.print.Location = new System.Drawing.Point(18, 399);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(110, 23);
            this.print.TabIndex = 8;
            this.print.Text = "Печатать";
            this.print.UseVisualStyleBackColor = true;
            this.print.Click += new System.EventHandler(this.print_Click);
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.back.Location = new System.Drawing.Point(35, 427);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 6;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // change
            // 
            this.change.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.change.Location = new System.Drawing.Point(18, 370);
            this.change.Name = "change";
            this.change.Size = new System.Drawing.Size(110, 23);
            this.change.TabIndex = 11;
            this.change.Text = "Заменить все";
            this.change.UseVisualStyleBackColor = true;
            this.change.Click += new System.EventHandler(this.change_Click);
            // 
            // start
            // 
            this.start.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.start.Location = new System.Drawing.Point(19, 341);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(110, 23);
            this.start.TabIndex = 12;
            this.start.Text = "Начать";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // loadBox
            // 
            this.loadBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.loadBox.FormattingEnabled = true;
            this.loadBox.Items.AddRange(new object[] {
            "Слабая",
            "Нормальная",
            "Перегрузка"});
            this.loadBox.Location = new System.Drawing.Point(8, 19);
            this.loadBox.Name = "loadBox";
            this.loadBox.Size = new System.Drawing.Size(121, 21);
            this.loadBox.TabIndex = 13;
            this.loadBox.SelectedIndexChanged += new System.EventHandler(this.loadBox_SelectedIndexChanged);
            // 
            // tempBar
            // 
            this.tempBar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tempBar.Location = new System.Drawing.Point(1, 65);
            this.tempBar.Maximum = 60;
            this.tempBar.Minimum = -40;
            this.tempBar.Name = "tempBar";
            this.tempBar.Size = new System.Drawing.Size(128, 45);
            this.tempBar.TabIndex = 14;
            this.tempBar.Scroll += new System.EventHandler(this.tempBar_Scroll);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(5, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Нагрузка";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Температура";
            // 
            // tempL
            // 
            this.tempL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tempL.AutoSize = true;
            this.tempL.Location = new System.Drawing.Point(85, 43);
            this.tempL.Name = "tempL";
            this.tempL.Size = new System.Drawing.Size(23, 13);
            this.tempL.TabIndex = 18;
            this.tempL.Text = "0 C";
            // 
            // totalTimeL
            // 
            this.totalTimeL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.totalTimeL.AutoSize = true;
            this.totalTimeL.ForeColor = System.Drawing.SystemColors.ControlText;
            this.totalTimeL.Location = new System.Drawing.Point(3, 113);
            this.totalTimeL.Name = "totalTimeL";
            this.totalTimeL.Size = new System.Drawing.Size(89, 13);
            this.totalTimeL.TabIndex = 20;
            this.totalTimeL.Text = "Общее время: 0";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.start);
            this.panel2.Controls.Add(this.change);
            this.panel2.Controls.Add(this.totalTimeL);
            this.panel2.Controls.Add(this.loadBox);
            this.panel2.Controls.Add(this.tempL);
            this.panel2.Controls.Add(this.print);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.back);
            this.panel2.Controls.Add(this.tempBar);
            this.panel2.Location = new System.Drawing.Point(596, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(140, 456);
            this.panel2.TabIndex = 21;
            // 
            // cardsTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 459);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MinimumSize = new System.Drawing.Size(615, 375);
            this.Name = "cardsTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Прогнозы";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.cardsTest_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.forPrint.ResumeLayout(false);
            this.forPrint.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tempBar)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel workField;
        private System.Windows.Forms.Button print;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button change;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Panel forPrint;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.ComboBox loadBox;
        private System.Windows.Forms.TrackBar tempBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label tempL;
        private System.Windows.Forms.Label totalTimeL;
        private System.Windows.Forms.Panel panel2;
    }
}