﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deteils
{
    public partial class saveName : Form
    {

        cardsEdit card;
        bool closing;

        public saveName(cardsEdit card, bool closing)
        {
            InitializeComponent();

            this.Location = new Point(card.Location.X, card.Location.Y);
            this.card = card;
            this.closing = closing;
        }

        private void confirm_Click(object sender, EventArgs e)
        {
            if (nameT.Text != null && nameT.Text != "")
            {
                card.Save(nameT.Text);
                if (closing)
                card.main.Show();
                this.Close();
            }
        
        }
    }
}
