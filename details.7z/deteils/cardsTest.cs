﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Printing;

namespace deteils
{
    public partial class cardsTest : Form
    {
        public main main;
        private string connectionString;
        private List<element> elements = new List<element>();
        private List<type> typeL = new List<type>();
        private Bitmap image;
        public string name = "";
        private float loadF = 1;
        private int fullTime = 0;
        private int time;

        public cardsTest(main main, string connectionString)
        {
            InitializeComponent();

            this.Location = new Point(main.Location.X, main.Location.Y);
            this.main = main;
            this.connectionString = connectionString;
            this.main = main;


            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from type", con);
            DataTable typeDT = new DataTable();
            da.Fill(typeDT);

            for (int i = 0; i < typeDT.Rows.Count; i++)
            {
                typeL.Add(new type());
                typeL[typeL.Count - 1].name = typeDT.Rows[i][1].ToString();
                typeL[typeL.Count - 1].maxTime = Convert.ToInt32(typeDT.Rows[i][2]);
                typeL[typeL.Count - 1].action = typeDT.Rows[i][3].ToString();
            }
            con.Close();

            loadBox.SelectedIndex = 1;

            ToolTip tempTip = new ToolTip();
            tempTip.SetToolTip(tempBar, "Температура");

            ToolTip loadTip = new ToolTip();
            tempTip.SetToolTip(loadBox, "Нагрузка");
        }

        public void load(int id, string loadType, string name)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da;
            DataTable elementsDT = new DataTable();

            this.name = name;
            this.Text = name;

            con.Open();

            da = new SqlDataAdapter("select * from details where cardId=\'" + id + "\';", con);
            da.Fill(elementsDT);

            for (int i = 0; i < elementsDT.Rows.Count; i++)
            {
                if (elementsDT.Rows[i][3].ToString() == "")
                {
                    elements.Add(new element(connectionString ,typeL, workField, elements, loadType));
                    elements[elements.Count - 1].name = elementsDT.Rows[i][2].ToString();

                    elements[elements.Count - 1].typeL.Text = elementsDT.Rows[i][4].ToString();

                    for (int j = 0; j < typeL.Count; j++)
                    {
                        if (typeL[j].name == elements[elements.Count - 1].typeL.Text)
                        {
                            elements[elements.Count - 1].durability = typeL[j].maxTime;
                            elements[elements.Count - 1].type = typeL[j].name;
                        }
                    }
                    elements[elements.Count - 1].timeWork = Convert.ToInt32(elementsDT.Rows[i][5]);   
                }
                else
                {
                    int perentId = 0;
                    for (int j = 0; j < elements.Count; j++)
                    {
                        if (elements[j].name == elementsDT.Rows[i][3].ToString())
                            perentId = j;
                    }

                    elements.Add(new element(connectionString ,typeL, workField, elements, elements[perentId], loadType, 0));
                    elements[perentId].children.Add(elements[i]);
                    elements[elements.Count - 1].name = elementsDT.Rows[i][2].ToString();
                    elements[elements.Count - 1].typeL.Text = elementsDT.Rows[i][4].ToString();

                    for (int j = 0; j < typeL.Count; j++)
                    {
                        if (typeL[j].name == elements[elements.Count - 1].typeL.Text)
                        {
                            elements[elements.Count - 1].durability = typeL[j].maxTime;
                            elements[elements.Count - 1].type = typeL[j].name;
                        }
                    }
                    elements[elements.Count - 1].timeWork = Convert.ToInt32(elementsDT.Rows[i][5]);
                }

                if (elements[elements.Count - 1].type == typeL[6].name || elements[elements.Count - 1].type == typeL[7].name)
                {
                    elements[elements.Count - 1].engineSpeed.Value = Convert.ToInt32(elementsDT.Rows[i][6]);
                }
                if (elements[elements.Count - 1].type == typeL[12].name)
                {
                    elements[elements.Count - 1].winchSpeed.SelectedIndex = Convert.ToInt32(elementsDT.Rows[i][6]);
                }
                if (elements[elements.Count - 1].type == typeL[14].name)
                {
                    elements[elements.Count - 1].volt.Text = elementsDT.Rows[i][6].ToString();
                }

            }

            elements[elements.Count - 1].replace();

            for (int i = 0; i < elements.Count; i++)
            {
                elements[i].timer = elements[i].timeWork;
            }

            DataTable used = new DataTable();
            da = new SqlDataAdapter("select * from usedDetails", con);
            da.Fill(used);

            for (int i=0; i<used.Rows.Count; i++)
            {
                foreach(element el in elements)
                {
                    if(el.type== used.Rows[i][1].ToString())
                    {
                        if(used.Rows[i][3].ToString()=="")
                        {
                            el.testTime = el.durability - Convert.ToInt32(used.Rows[i][2]);
                        }
                        else
                        {
                            if (el.perent.type == used.Rows[i][3].ToString())
                            {
                                el.testTime = el.durability - Convert.ToInt32(used.Rows[i][2]);
                            }
                        }
                    }
                }
            }


            con.Close();

            foreach (element el in elements)
            {
                if ((el.durability - el.testTime) > 0)
                    el.timeWorkedL.Text = ((el.durability - el.testTime) / ((double)el.durability / 100)).ToString("#.##") + "%";
                else
                    el.timeWorkedL.Text = "0%";
            }

            List<int> getMax = new List<int>();

            foreach(element el in elements)
            {
                getMax.Add(el.timeWork);
            }

            time = getMax.Max();
            
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void print_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < elements.Count; i++)
            {
                elements[i].analise.Hide();
                elements[i].changeB.Hide();
            }

            PrintDialog myPrintDialog = new PrintDialog();
            if (myPrintDialog.ShowDialog() == DialogResult.OK)
            {
                PrinterSettings values;
                values = myPrintDialog.PrinterSettings;
                myPrintDialog.Document = printDocument1;
                printDocument1.DefaultPageSettings.PaperSize = new PaperSize("drow cards", forPrint.Width + 10 * (forPrint.Width / 232), forPrint.Height + 15);
                printDocument1.PrintPage += PrintPage;
                printDocument1.PrintController = new StandardPrintController();
                printDocument1.Print();
            }
            printDocument1.Dispose();

            for (int i = 0; i < elements.Count; i++)
            {
                elements[i].analise.Show();
                elements[i].changeB.Show();
            }
        }

        private void PrintPage(object o, PrintPageEventArgs e)
        {
            image = new Bitmap(forPrint.Width, forPrint.Height);
            forPrint.DrawToBitmap(image, forPrint.ClientRectangle);
            Point loc = new Point(0, 0);
            e.Graphics.DrawImage(image, loc);
        }

        private void cardsTest_FormClosing(object sender, FormClosingEventArgs e)
        {
            main.Show();

            DataTable stat = new DataTable();
            SqlConnection con = new SqlConnection(main.connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, main.user, "Завершил работу с прогнозами", DateTime.Now);

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(stat);
            con.Close();
        }

        private void restore_Click(object sender, EventArgs e)
        {

        }

        private void change_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < elements.Count; i++)
            {
                elements[i].change();
            }
        }

        private void loadBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (loadBox.SelectedIndex == 0)
                loadF = 0.5f;
            if (loadBox.SelectedIndex == 1)
                loadF = 1f;
            if (loadBox.SelectedIndex == 2)
                loadF = 1.5f;
        }

        private void start_Click(object sender, EventArgs e)
        {

            int workedOutEngines = 0;
            int enginesCount = 0;

            #region preTest
            foreach (element el in elements)
            {
                el.timer = el.timeWork;

               if (el.type == typeL[6].name)
                {
                    enginesCount++;                  
                }

                if (el.type == typeL[7].name)
                {
                    enginesCount++;
                }
               

                if (el.type == typeL[14].name)
                {
                    if (Convert.ToInt32(el.volt.Text)/10>el.maxV)
                    {                      
                        el.durability = el.durability - el.durability/100 * (Convert.ToInt32(el.volt.Text) / 10-el.maxV)*8;
                        el.maxV = Convert.ToInt32(el.volt.Text) / 10;
                    }
                }

                if (el.testTime >= el.durability)
                {
                    el.workedOut = true;
                }

                if (el.typeL.Text == typeL[2].name && (tempBar.Value <= -40 || tempBar.Value >= 40))
                {
                    el.workedOut = true;
                }
                else
                {
                    if (el.typeL.Text == typeL[2].name && (tempBar.Value > -40 && tempBar.Value < 40))
                    {
                        el.workedOut = false;                       
                    }
                }

                if (el.typeL.Text == typeL[11].name && (tempBar.Value <= -40 || tempBar.Value >= 60))
                {
                    el.workedOut = true;
                }
                else
                {
                    if (el.typeL.Text == typeL[11].name && (tempBar.Value > -40 && tempBar.Value < 60))
                    {
                        el.workedOut = false;
                        if (el.perent.testTime < el.perent.durability)
                        {
                            el.perent.workedOut = false;
                        }
                    }
                }
    

                if ((el.type == typeL[6].name || el.type == typeL[7].name) && el.workedOut)
                {
                    workedOutEngines++;
                    foreach (element child in el.children)
                    {
                        if (child.type == typeL[0].name || child.type == typeL[8].name)
                        {
                            child.workedOut = true;
                        }
                    }
                }

                if (el.typeL.Text == typeL[3].name && el.workedOut)
                {
                    foreach (element element in elements)
                    {
                        if (element.typeL.Text == typeL[2].name || element.typeL.Text == typeL[11].name)
                        {
                            element.workedOut = true;
                        }
                    }
                }

                if (el.typeL.Text == typeL[4].name && el.workedOut)
                {
                    foreach (element element in elements)
                    {
                        element.workedOut = true;
                        element.timeWorkedL.Hide();
                        element.errorMes.Hide();
                        
                    }
                }

                if (el.typeL.Text == typeL[5].name && el.workedOut)
                {
                    el.perent.workedOut = true;
                }

                if (el.typeL.Text == typeL[8].name && el.workedOut && !el.perent.enginePistone)
                {
                    el.perent.durability = el.perent.durability - (el.perent.durability / 100 * 30);
                    el.perent.enginePistone = true;
                }

                if (el.typeL.Text == typeL[9].name && el.perent.workedOut)
                {
                    el.workedOut = true;
                }

                if (el.typeL.Text == typeL[10].name && el.workedOut)
                {
                    el.perent.workedOut = true;
                }

                if (el.typeL.Text == typeL[11].name && el.workedOut)
                {
                    el.perent.workedOut = true;
                }

                if(el.typeL.Text == typeL[13].name && el.workedOut)
                {
                    foreach (element child in el.children)
                    {
                        if (child.type == typeL[11].name)
                        {
                            child.workedOut = true;
                        }
                    }
                }

                if (el.typeL.Text == typeL[14].name && el.workedOut)
                {
                    foreach (element child in el.children)
                    {
                        if (child.type == typeL[2].name || child.type == typeL[11].name)
                        {
                            child.workedOut = true;
                        }
                    }
                }
            }

            if (workedOutEngines == enginesCount)
            {
                foreach (element element in elements)
                {
                    element.workedOut = true;                   
                }
            }

            workedOutEngines = 0;

            #endregion

            for (int i = 0; i < time; i++)
            {
                foreach (element el in elements)
                {
                    if (!el.workedOut && el.timer>0)
                    {
                        if (el.type != typeL[12].name)
                        {
                            if (el.type != typeL[6].name)
                            {
                                if (el.type != typeL[7].name)
                                {
                                    el.testTime += loadF;
                                }
                                else
                                {
                                    if (el.engineSpeed.Value > 1000)
                                    {
                                        el.testTime += loadF + ((el.engineSpeed.Value - 1000) / 500) * (loadF / 5);
                                    }
                                    else
                                    {
                                        el.testTime += loadF;
                                    }
                                }
                            }
                            else
                            {
                                if(el.engineSpeed.Value>1500)
                                {
                                    el.testTime += loadF + ((el.engineSpeed.Value-1500)/500)*(loadF/5);
                                }
                                else
                                {
                                    el.testTime += loadF;
                                }
                            }
                        }
                        else
                        {
                            if (el.winchSpeed.SelectedIndex == 0)
                                el.testTime += 0.5f;
                            else
                                el.testTime += 1;
                        }

                        if (((el.durability - el.testTime) / ((double)el.durability / 100)) > 0)
                            el.timeWorkedL.Text = ((el.durability - el.testTime) / ((double)el.durability / 100)).ToString("#.##") + "%";
                        else
                            el.timeWorkedL.Text = "0%";

                        el.timer--;
                    }

                    if (el.testTime >= el.durability)
                    {
                        el.workedOut = true;
                    }
                }
                foreach (element el in elements)
                { 
                    if (el.typeL.Text == typeL[0].name && el.workedOut)
                    {
                        if (!el.perent.workedOut)
                        {
                            el.perent.timeAfterWorkOut++;
                            if (el.perent.timeAfterWorkOut == 1000)
                            {
                                el.perent.timeAfterWorkOut = 0;

                                el.perent.durability = el.perent.durability - (el.perent.durability / 100 * 5);       

                                if (el.perent.timeWork >= el.perent.durability)
                                {
                                    el.perent.workedOut = true;
                                }
                            }
                        }
                    }

                    if (el.typeL.Text == typeL[2].name && el.workedOut)
                    {
                        if (!el.perent.workedOut)
                        {
                            el.perent.timeAfterWorkOut++;
                            if (el.perent.timeAfterWorkOut == 1000)
                            {
                                el.perent.timeAfterWorkOut = 0;

                                el.perent.durability = el.perent.durability - (el.perent.durability / 10);

                                if (el.perent.timeWork >= el.perent.durability)
                                {
                                    el.perent.workedOut = true;
                                }
                            }
                        }
                    }

                    if (el.typeL.Text == typeL[3].name && el.workedOut)
                    {
                        foreach (element element in elements)
                        {
                            if (element.typeL.Text == typeL[2].name || element.typeL.Text == typeL[11].name)
                            {
                                element.workedOut = true;
                            }
                        }
                    }

                    if (el.typeL.Text == typeL[4].name && el.workedOut)
                    {
                        foreach (element element in elements)
                        {
                            element.workedOut = true;
                            element.timeWorkedL.Hide();
                            element.errorMes.Hide();                         
                        }

                        break;
                    }

                    if (el.typeL.Text == typeL[5].name && el.workedOut)
                    {
                        el.perent.workedOut = true;
                    }

                    if ((el.typeL.Text == typeL[6].name || el.typeL.Text == typeL[7].name) && el.workedOut)
                    {
                        workedOutEngines++;

                        foreach (element child in el.children)
                        {
                            if (child.type == typeL[0].name || child.type == typeL[8].name)
                            {
                                child.workedOut = true;
                            }
                        }
                    }

                    if (workedOutEngines==enginesCount)
                    {
                        foreach (element element in elements)
                        {
                            element.workedOut = true;                                           
                        }

                        break;
                    }

                    if (el.typeL.Text == typeL[8].name && el.workedOut && !el.perent.enginePistone)
                    {
                        el.perent.durability = el.perent.durability - (el.perent.durability/100*30);
                        el.perent.enginePistone = true;
                    }

                    if (el.typeL.Text == typeL[9].name && el.perent.workedOut)
                    {
                        el.workedOut = true;
                    }

                    if (el.typeL.Text == typeL[10].name && el.workedOut)
                    {
                        el.perent.workedOut = true;
                    }

                    if (el.typeL.Text == typeL[11].name && el.workedOut)
                    {
                        el.perent.workedOut = true;
                    }

                    if (el.typeL.Text == typeL[13].name && el.workedOut)
                    {
                        foreach (element child in el.children)
                        {
                            if (child.type == typeL[11].name)
                            {
                                child.workedOut = true;
                            }
                        }
                    }

                    if (el.typeL.Text == typeL[14].name && el.workedOut)
                    {
                        foreach (element child in el.children)
                        {
                            if (child.type == typeL[2].name || child.type == typeL[11].name)
                            {
                                child.workedOut = true;
                            }
                        }
                    }
                }
                fullTime++;

            }

            foreach(element el in elements)
            {
                foreach (type t in typeL)
                {
                    if (el.type==t.name)
                    {
                        if(el.testTime>=el.durability)
                        {
                            el.errorMes.Text = t.action;
                        }
                        else
                        {
                            el.errorMes.Text = "";
                        }
                    }
                }
            }

            totalTimeL.Text = "Общее время: "+ fullTime.ToString();

            workField.Refresh();

            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from usedDetails", con);
            DataTable used = new DataTable();
            con.Open();
            string sql = "DELETE FROM usedDetails";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            da.Fill(used);

            int id = 0;
            foreach(element el in elements)
            {
                id++;
                if((el.durability-el.testTime)<el.durability)
                {
                    if(el.type==typeL[0].name || el.type == typeL[8].name || el.type == typeL[9].name)
                    {
                        used.Rows.Add(id,el.type, el.durability - el.testTime, el.perent.type);
                    }
                    else
                    {
                        used.Rows.Add(id, el.type, el.durability - el.testTime, "");
                    }
                }

                
            }
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(used);
            con.Close();
        }

        private void tempBar_Scroll(object sender, EventArgs e)
        {
            tempL.Text = tempBar.Value.ToString()+ " C";
        }
      
    }
}
