﻿namespace deteils
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.editDB = new System.Windows.Forms.Button();
            this.editUsers = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.progn = new System.Windows.Forms.Button();
            this.cards = new System.Windows.Forms.DataGridView();
            this.create = new System.Windows.Forms.Button();
            this.open = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.statB = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cards)).BeginInit();
            this.SuspendLayout();
            // 
            // editDB
            // 
            this.editDB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.editDB.Location = new System.Drawing.Point(503, 374);
            this.editDB.Name = "editDB";
            this.editDB.Size = new System.Drawing.Size(100, 41);
            this.editDB.TabIndex = 0;
            this.editDB.Text = "Редактировать базу данных";
            this.editDB.UseVisualStyleBackColor = true;
            this.editDB.Visible = false;
            this.editDB.Click += new System.EventHandler(this.editDB_Click);
            // 
            // editUsers
            // 
            this.editUsers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.editUsers.Location = new System.Drawing.Point(503, 421);
            this.editUsers.Name = "editUsers";
            this.editUsers.Size = new System.Drawing.Size(100, 41);
            this.editUsers.TabIndex = 1;
            this.editUsers.Text = "Редактировать пользователей";
            this.editUsers.UseVisualStyleBackColor = true;
            this.editUsers.Visible = false;
            this.editUsers.Click += new System.EventHandler(this.editUsers_Click);
            // 
            // back
            // 
            this.back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.back.Location = new System.Drawing.Point(503, 468);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(100, 23);
            this.back.TabIndex = 2;
            this.back.Text = "Выйти";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // progn
            // 
            this.progn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.progn.Location = new System.Drawing.Point(503, 70);
            this.progn.Name = "progn";
            this.progn.Size = new System.Drawing.Size(100, 23);
            this.progn.TabIndex = 4;
            this.progn.Text = "Прогнозы";
            this.progn.UseVisualStyleBackColor = true;
            this.progn.Click += new System.EventHandler(this.progn_Click);
            // 
            // cards
            // 
            this.cards.AllowUserToAddRows = false;
            this.cards.AllowUserToDeleteRows = false;
            this.cards.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cards.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.cards.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.cards.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cards.Location = new System.Drawing.Point(12, 12);
            this.cards.Name = "cards";
            this.cards.ReadOnly = true;
            this.cards.Size = new System.Drawing.Size(485, 479);
            this.cards.TabIndex = 5;
            // 
            // create
            // 
            this.create.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.create.Location = new System.Drawing.Point(503, 12);
            this.create.Name = "create";
            this.create.Size = new System.Drawing.Size(100, 23);
            this.create.TabIndex = 6;
            this.create.Text = "Создать новый";
            this.create.UseVisualStyleBackColor = true;
            this.create.Click += new System.EventHandler(this.create_Click);
            // 
            // open
            // 
            this.open.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.open.Location = new System.Drawing.Point(503, 41);
            this.open.Name = "open";
            this.open.Size = new System.Drawing.Size(100, 23);
            this.open.TabIndex = 7;
            this.open.Text = "Открыть";
            this.open.UseVisualStyleBackColor = true;
            this.open.Click += new System.EventHandler(this.open_Click);
            // 
            // delete
            // 
            this.delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.delete.Location = new System.Drawing.Point(503, 99);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(100, 23);
            this.delete.TabIndex = 8;
            this.delete.Text = "Удалить";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // statB
            // 
            this.statB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.statB.Location = new System.Drawing.Point(503, 345);
            this.statB.Name = "statB";
            this.statB.Size = new System.Drawing.Size(100, 23);
            this.statB.TabIndex = 9;
            this.statB.Text = "Статистика";
            this.statB.UseVisualStyleBackColor = true;
            this.statB.Visible = false;
            this.statB.Click += new System.EventHandler(this.statB_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 503);
            this.Controls.Add(this.statB);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.open);
            this.Controls.Add(this.create);
            this.Controls.Add(this.cards);
            this.Controls.Add(this.progn);
            this.Controls.Add(this.back);
            this.Controls.Add(this.editUsers);
            this.Controls.Add(this.editDB);
            this.MinimumSize = new System.Drawing.Size(414, 321);
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Главное меню";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.main_FormClosed);
            this.VisibleChanged += new System.EventHandler(this.main_VisibleChanged);
            ((System.ComponentModel.ISupportInitialize)(this.cards)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button editDB;
        private System.Windows.Forms.Button editUsers;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button progn;
        private System.Windows.Forms.DataGridView cards;
        private System.Windows.Forms.Button create;
        private System.Windows.Forms.Button open;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button statB;
    }
}