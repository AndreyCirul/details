﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace deteils
{
    public partial class workWhisDb : Form
    {
        private main main;
        private DataTable cardsDT = new DataTable();
        private SqlDataAdapter cardsDA;
        private DataTable detailsDT = new DataTable();
        private SqlDataAdapter detailsDA;
        private DataTable usersDT = new DataTable();
        private SqlDataAdapter usersDA;
        private DataTable statDT = new DataTable();
        private SqlDataAdapter statDA;
        private DataTable typeDT = new DataTable();
        private SqlDataAdapter typeDA;
        private string connectioString;

        public workWhisDb(main main)
        {
            InitializeComponent();

            this.Location = new Point(main.Location.X, main.Location.Y);
            this.main = main;

            connectioString = main.connectionString;

            SqlConnection con = new SqlConnection(connectioString);

            con.Open();
            cardsDA = new SqlDataAdapter("select * from cards", con);
            cardsDA.Fill(cardsDT);

            detailsDA = new SqlDataAdapter("select * from details", con);
            detailsDA.Fill(detailsDT);

            usersDA = new SqlDataAdapter("select * from Users", con);
            usersDA.Fill(usersDT);

            statDA = new SqlDataAdapter("select * from statistic", con);
            statDA.Fill(statDT);

            typeDA = new SqlDataAdapter("select * from type", con);
            typeDA.Fill(typeDT);

            con.Close();
        }

        private void save_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connectioString);
            SqlCommandBuilder cb;

            con.Open();

            cb = new SqlCommandBuilder(cardsDA);
            cardsDA.Update(cardsDT);
            cb = new SqlCommandBuilder(detailsDA);
            detailsDA.Update(detailsDT);
            cb = new SqlCommandBuilder(usersDA);
            usersDA.Update(usersDT);
            cb = new SqlCommandBuilder(statDA);
            statDA.Update(statDT);
            cb = new SqlCommandBuilder(typeDA);
            typeDA.Update(typeDT);

            con.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();

            DataTable stat = new DataTable();
            SqlConnection con = new SqlConnection(main.connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, main.user, "Завершил работу с базами данных", DateTime.Now);

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(stat);
            con.Close();
        }

        private void Tables_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Tables.SelectedIndex == 0)
                tableDG.DataSource = cardsDT;
            if (Tables.SelectedIndex == 1)
                tableDG.DataSource = detailsDT;
            if (Tables.SelectedIndex == 2)
                tableDG.DataSource = usersDT;
            if (Tables.SelectedIndex == 3)
                tableDG.DataSource = statDT;
            if (Tables.SelectedIndex == 4)
                tableDG.DataSource = typeDT;
        }

        private void workWhisDb_FormClosing(object sender, FormClosingEventArgs e)
        {
            main.Show();
        }
    }
}
