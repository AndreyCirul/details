﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace deteils
{
    public partial class main : Form
    {
        private Login login;
        public string user;
        public string connectionString;
        private DataTable cardsDT = new DataTable();

        public main(Login log, string conectionS,string userName, bool admin)
        {
            InitializeComponent();

            this.Location = new Point(log.Location.X, log.Location.Y);
            if (admin)
            {
                editDB.Show();
                editUsers.Show();
                statB.Show();
            } 

            login = log;
            connectionString = conectionS;
            user = userName;

            updateDT();


        }

        private void updateDT()
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select Id, name as 'Имя', createBy as 'Создал', createDate as 'Дата создания', editDate as 'Дата последнего изменения' from cards", con);

            con.Open();
            cardsDT.Clear();
            da.Fill(cardsDT);
            cards.DataSource = cardsDT;

            cards.Columns[0].Visible = false;

            con.Close();
        }

        private void main_FormClosed(object sender, FormClosedEventArgs e)
        {
            login.Show();

            DataTable stat = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, user, "Вышел", DateTime.Now);

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(stat);
            con.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        } 

        private void editUsers_Click(object sender, EventArgs e)
        {
            usersList users = new usersList(this);
            users.Show();
            this.Enabled = false;

            DataTable stat = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, user, "Открыл окно изменения пользователей", DateTime.Now);

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(stat);
            con.Close();
        }

        private void create_Click(object sender, EventArgs e)
        {
            cardsEdit card = new cardsEdit(this, connectionString, user);
            card.create();
            card.Show();
            this.Hide();

            DataTable stat = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, user, "Зашел в окно создания проектов", DateTime.Now);

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(stat);
            con.Close();
        }

        private void open_Click(object sender, EventArgs e)
        {
            if (cards.CurrentCell != null)
            {
                cardsEdit card = new cardsEdit(this, connectionString, user);
                card.load(cards.CurrentCell.RowIndex + 1, "create", cardsDT.Rows[cards.CurrentCell.RowIndex][1].ToString());
                card.Show();
                this.Hide();

                DataTable stat = new DataTable();
                SqlConnection con = new SqlConnection(connectionString);
                SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
                con.Open();
                da.Fill(stat);

                int id = 1;
                if (stat.Rows.Count != 0)
                {
                    id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
                }


                stat.Rows.Add(id, user, "Открыл проект " + cardsDT.Rows[cards.CurrentCell.RowIndex][1].ToString(), DateTime.Now);

                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                da.Update(stat);
                con.Close();
            }
        }

        private void main_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible==true)
                updateDT();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            DataTable stat = new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            

            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, user, "Удалил проект " + cardsDT.Rows[cards.CurrentCell.RowIndex][1].ToString(), DateTime.Now);

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(stat);

            string sql = "DELETE FROM details where cardId=\'" + cardsDT.Rows[cards.CurrentCell.RowIndex][0] + "\'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

            sql = "DELETE FROM cards where Id=\'" + cardsDT.Rows[cards.CurrentCell.RowIndex][0] + "\'";
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();

            con.Close();
            updateDT();
        }

        private void editDB_Click(object sender, EventArgs e)
        {
            workWhisDb db = new workWhisDb(this);
            db.Show();
            this.Hide();

            DataTable stat =new DataTable();
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
            con.Open();
            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, user, "Открыл окно изменения базы данных", DateTime.Now);

            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(stat);
            con.Close();
        }

        private void progn_Click(object sender, EventArgs e)
        {
            if (cards.CurrentCell != null)
            {
                cardsTest card = new cardsTest(this, connectionString);
                card.Show();


                card.load(cards.CurrentCell.RowIndex + 1, "test", cardsDT.Rows[cards.CurrentCell.RowIndex][1].ToString());
                this.Hide();

                DataTable stat = new DataTable();
                SqlConnection con = new SqlConnection(connectionString);
                SqlDataAdapter da = new SqlDataAdapter("select * from statistic", con);
                con.Open();
                da.Fill(stat);

                int id = 1;
                if (stat.Rows.Count != 0)
                {
                    id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
                }


                stat.Rows.Add(id, user, "Открыл прогнозы проекта " + cardsDT.Rows[cards.CurrentCell.RowIndex][1].ToString(), DateTime.Now);

                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                da.Update(stat);
                con.Close();
            }
        }

        private void statB_Click(object sender, EventArgs e)
        {
            statShow stat = new statShow(this);
            stat.Show();
            this.Hide();
        }
    }
}
