﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace deteils
{
    public partial class Login : Form
    {
        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;
        private string encriptPass = "P@$$w0rd";
        string serverName;
        string conectionString;

        public Login()
        {
            InitializeComponent();

            StreamReader sr = new StreamReader("serverName.txt");
            serverName = sr.ReadLine();
            conectionString = "Data Source=" + serverName + ";Initial Catalog=deteilsBD;Integrated Security=True";
        }

        private void regist_Click(object sender, EventArgs e)
        {
            register reg = new register(this, conectionString);
            reg.Show();
            this.Hide();
        }

        private void enter_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conectionString);
            SqlDataAdapter da;
            DataTable usersDT = new DataTable();
            DataTable stat = new DataTable();

            con.Open();
            da = new SqlDataAdapter("select * from Users", con);
            da.Fill(usersDT);

            bool enter = false;
            for (int i = 0; i < usersDT.Rows.Count; i++)
            {
                if (EncryptString(log.Text, encriptPass) == usersDT.Rows[i][1].ToString() && EncryptString(pass.Text, encriptPass) == usersDT.Rows[i][2].ToString())
                {
                    main main = new main(this, conectionString, log.Text, Convert.ToBoolean(usersDT.Rows[i][3]));
                    main.Show();
                    this.Hide();


                    //дабавить в статистику
                    da = new SqlDataAdapter("select * from statistic", con);
                    da.Fill(stat);

                    int id = 1;
                    if (stat.Rows.Count != 0)
                    {
                        id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
                    }

                    stat.Rows.Add(id, log.Text, "Вошел в систему", DateTime.Now);

                    SqlCommandBuilder cb = new SqlCommandBuilder(da);
                    da.Update(stat);
                    enter = true;
                    break;
                }

            }
            if (!enter)
                if (log.Text == null || log.Text == "" || pass.Text == null || pass.Text == "")
                    MessageBox.Show("Поля не заполнены");
                else
                    MessageBox.Show("Логин или пароль введены неправильно");

            con.Close();
        }

        public static string EncryptString(string plainText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        private void Login_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible == true)
            {
                log.Text = "";
                pass.Text = "";
            }
        }
    }
}
