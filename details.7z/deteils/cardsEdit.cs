﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Printing;

namespace deteils
{
    public partial class cardsEdit : Form
    {
        public main main;
        private string connectionString;
        private string user;
        private List<element> elements = new List<element>();
        private List<type> typeL = new List<type>();
        private Bitmap image;
        public string name = "";       

        public cardsEdit(main main, string connectionString, string user)
        {
            InitializeComponent();

            this.Location = new Point(main.Location.X, main.Location.Y);
            this.connectionString = connectionString;
            this.main = main;
            this.user = user;

            SqlConnection con = new SqlConnection(connectionString);          
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from type",con);
            DataTable typeDT = new DataTable();
            da.Fill(typeDT);

            for (int i = 0; i<typeDT.Rows.Count; i++)
            {
                typeL.Add(new type());
                typeL[typeL.Count - 1].name = typeDT.Rows[i][1].ToString();
                typeL[typeL.Count - 1].maxTime =Convert.ToInt32(typeDT.Rows[i][2]);
                typeL[typeL.Count - 1].action = typeDT.Rows[i][3].ToString();
            }


            con.Close();
            this.Text = "Новый проект";
        }

        public void create()
        {
            elements.Add(new element(connectionString, typeL, workField, elements, "create"));
        }

        public void load(int id, string loadType, string name)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da;      
            DataTable elementsDT = new DataTable();

            this.name = name;
            this.Text = name;

            con.Open();

            da = new SqlDataAdapter("select * from details where cardId=\'" + id + "\';", con);
            da.Fill(elementsDT);

            for (int i=0; i<elementsDT.Rows.Count; i++)
            {
                if (elementsDT.Rows[i][3].ToString()=="")
                {               
                    elements.Add(new element(connectionString ,typeL, workField, elements, loadType));
                    elements[elements.Count - 1].name = elementsDT.Rows[i][2].ToString();
                    for (int j=0; j < elements[elements.Count - 1].typeBox.Items.Count; j++)
                    {
                        if(elements[elements.Count - 1].typeBox.Items[j].ToString() == elementsDT.Rows[i][4].ToString())
                        {
                            elements[elements.Count - 1].typeBox.SelectedIndex = j;
                        }
                    }
                    elements[elements.Count - 1].timeWorked.Text = elementsDT.Rows[i][5].ToString();
                    elements[elements.Count - 1].timeWork = Convert.ToInt32(elementsDT.Rows[i][5]);
                }
                else
                {
                    int perentId = 0;
                    for (int j=0; j< elements.Count; j++)
                    {                        
                        if (elements[j].name == elementsDT.Rows[i][3].ToString())
                            perentId = j;
                    }

                    elements.Add(new element(connectionString, typeL, workField, elements, elements[perentId], loadType, 0));
                    elements[perentId].children.Add(elements[i]);
                    elements[elements.Count - 1].name = elementsDT.Rows[i][2].ToString();
                    for (int j = 0; j < elements[elements.Count - 1].typeBox.Items.Count; j++)
                    {
                        if (elements[elements.Count - 1].typeBox.Items[j].ToString() == elementsDT.Rows[i][4].ToString())
                        {
                            elements[elements.Count - 1].typeBox.SelectedIndex = j;
                        }
                    }
                    elements[elements.Count - 1].timeWorked.Text = elementsDT.Rows[i][5].ToString();
                }

                if (elements[elements.Count - 1].type == typeL[6].name || elements[elements.Count - 1].type == typeL[7].name)
                {
                    elements[elements.Count - 1].engineSpeed.Value = Convert.ToInt32(elementsDT.Rows[i][6]);
                    elements[elements.Count - 1].engineSpeedL.Text = elements[elements.Count - 1].engineSpeed.Value.ToString() + " обоотов в минуту";
                }
                if (elements[elements.Count - 1].type == typeL[12].name)
                {
                    elements[elements.Count - 1].winchSpeed.SelectedIndex = Convert.ToInt32(elementsDT.Rows[i][6]);
                }
                if (elements[elements.Count - 1].type == typeL[14].name)
                {
                    elements[elements.Count - 1].volt.Text = elementsDT.Rows[i][6].ToString();
                }
            }

            elements[elements.Count - 1].replace();

             DataTable used = new DataTable();
            da = new SqlDataAdapter("select * from usedDetails", con);
            da.Fill(used);

            for (int i=0; i<used.Rows.Count; i++)
            {
                foreach(element el in elements)
                {
                    if(el.type== used.Rows[i][1].ToString())
                    {
                        if(used.Rows[i][3].ToString()=="")
                        {
                            el.durability = Convert.ToInt32(used.Rows[i][2]);
                            el.maxTimeL.Text = el.durability.ToString();
                        }
                        else
                        {
                            if (el.perent.type == used.Rows[i][3].ToString())
                            {
                                el.durability =Convert.ToInt32(used.Rows[i][2]);
                                el.maxTimeL.Text = el.durability.ToString();
                            }
                        }
                    }
                }
            }
            con.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void Save(string name)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da;
            SqlCommandBuilder cb;
            DataTable cardsDT = new DataTable();
            DataTable elementsDT = new DataTable();

            con.Open();

            da = new SqlDataAdapter("select * from cards where name=\'" + name + "\';", con);
            da.Fill(cardsDT);


            if (!(this.name == "" && cardsDT.Rows.Count > 0))
            {
                #region saveCard
                DateTime createdDate = DateTime.Today;
                
                if (cardsDT.Rows.Count > 0)
                    createdDate = Convert.ToDateTime(cardsDT.Rows[0][3]);

                cardsDT.Clear();
                string sql = "DELETE FROM cards where name=\'" + name + "\'";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();

                da = new SqlDataAdapter("select * from cards", con);
                da.Fill(cardsDT);


                int newID = 0;
                for (int i = 0; i < cardsDT.Rows.Count; i++)
                {
                    if ((i + 1).ToString() != cardsDT.Rows[i][0].ToString())
                    {
                        newID = i + 1;
                        break;
                    }
                }

                int idCard = 0;

                if (newID == 0)
                {
                    cardsDT.Rows.Add(cardsDT.Rows.Count + 1, name, user, createdDate.ToShortDateString(), DateTime.Today.ToShortDateString());
                    idCard = cardsDT.Rows.Count;
                }
                else
                {
                    cardsDT.Rows.Add(newID, name, user, createdDate.ToShortDateString(), DateTime.Today.ToShortDateString());
                    idCard = newID;
                }

                

                cb = new SqlCommandBuilder(da);
                da.Update(cardsDT);
                cardsDT.Clear();
                #endregion

                #region saveElements
                for (int i = 0; i < elements.Count; i++)
                {
                    elements[i].name = "element" + i.ToString();
                }

                sql = "DELETE FROM details where cardId=\'" + idCard + "\'";
                cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();

                

                for (int i = 0; i < elements.Count; i++)
                {
                    elementsDT.Clear();
                    da = new SqlDataAdapter("select * from details", con);
                    da.Fill(elementsDT);

                    newID = 0;
                    for (int j = 0; j < elementsDT.Rows.Count; j++)
                    {
                        if ((j + 1).ToString() != elementsDT.Rows[j][0].ToString())
                        {
                            newID = j + 1;
                            break;
                        }
                    }

                    int timeWorked = Convert.ToInt32(elements[i].timeWorked.Text);

                    if (newID == 0)
                    {
                        if (elements[i].perent != null)
                        {
                            if (elements[i].type == typeL[6].name || elements[i].type == typeL[7].name)
                            {
                                elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked, elements[i].engineSpeed.Value);
                            }
                            else
                            {
                                if (elements[i].type == typeL[12].name)
                                {
                                    elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked, elements[i].winchSpeed.SelectedIndex);
                                }
                                else
                                {
                                    if (elements[i].type == typeL[14].name)
                                    {
                                        elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked, Convert.ToInt32(elements[i].volt.Text));
                                    }
                                    else
                                    {
                                        elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked);
                                    }
                                }
                            }
                        }
                        else
                        {
                            
                                if (elements[i].type == typeL[6].name || elements[i].type == typeL[7].name)
                                {
                                    elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, "", elements[i].type, timeWorked, elements[i].engineSpeed.Value);
                                }
                                else
                                {
                                    if (elements[i].type == typeL[12].name)
                                    {
                                        elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, "", elements[i].type, timeWorked, elements[i].winchSpeed.SelectedIndex);
                                    }
                                    else
                                    {
                                        if (elements[i].type == typeL[14].name)
                                        {
                                            elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, "", elements[i].type, timeWorked, Convert.ToInt32(elements[i].volt.Text));
                                        }
                                        else
                                        {
                                            elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, "", elements[i].type, timeWorked);
                                        }
                                    }
                                }
                            }
                        
                    }
                    else
                    {
                        if (elements[i].perent != null)
                        {
                            if (elements[i].type == typeL[6].name || elements[i].type == typeL[7].name)
                            {
                                elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked, elements[i].engineSpeed.Value);
                            }
                            else
                            {
                                if (elements[i].type == typeL[12].name)
                                {
                                    elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked, elements[i].winchSpeed.SelectedIndex);
                                }
                                else
                                {
                                    if (elements[i].type == typeL[14].name)
                                    {
                                        elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked, Convert.ToInt32(elements[i].volt.Text));
                                    }
                                    else
                                    {
                                        elementsDT.Rows.Add(elementsDT.Rows.Count + 1, idCard, elements[i].name, elements[i].perent.name, elements[i].type, timeWorked);
                                    }
                                }
                            }
                        }
                        else
                        {
                            
                                if (elements[i].type == typeL[6].name || elements[i].type == typeL[7].name)
                                {
                                    elementsDT.Rows.Add(newID, idCard, elements[i].name, "", elements[i].type, timeWorked, elements[i].engineSpeed.Value);
                                }
                                else
                                {
                                    if (elements[i].type == typeL[12].name)
                                    {
                                        elementsDT.Rows.Add(newID, idCard, elements[i].name, "", elements[i].type, timeWorked, elements[i].winchSpeed.SelectedIndex);
                                    }
                                    else
                                    {
                                        if (elements[i].type == typeL[14].name)
                                        {
                                            elementsDT.Rows.Add(newID, idCard, elements[i].name, "", elements[i].type, timeWorked, Convert.ToInt32(elements[i].volt.Text));
                                        }
                                        else
                                        {
                                            elementsDT.Rows.Add(newID, idCard, elements[i].name, "", elements[i].type, timeWorked);
                                        }
                                    }
                                }
                            }
                        
                    }

                    cb = new SqlCommandBuilder(da);
                    da.Update(elementsDT);
                }

                

                #endregion

                this.name = name;
                this.Text = name;

                DataTable stat = new DataTable();
                da = new SqlDataAdapter("select * from statistic", con);
                da.Fill(stat);

                int id = 1;
                if (stat.Rows.Count != 0)
                {
                    id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
                }

                stat.Rows.Add(id, user, "Сохранил проект " + name, DateTime.Now);

                cb = new SqlCommandBuilder(da);
                da.Update(stat);
            }
            else
            {
                MessageBox.Show("Имя занято");
                saveName save = new saveName(this, false);
                save.Show();
            }
            con.Close();
        }    

        private void saveB_Click(object sender, EventArgs e)
        {
            if (name == "")
            {
                saveName save = new saveName(this, false);
                save.Show();
            }
            else
            {
                Save(name);
            }
        }

        private void print_Click(object sender, EventArgs e)
        {
            for (int i=0; i<elements.Count;i++)
            {
                if (elements[i].delete != null)
                    elements[i].delete.Hide();
                elements[i].add.Hide();
            }

            PrintDialog myPrintDialog = new PrintDialog();
            if (myPrintDialog.ShowDialog() == DialogResult.OK)
            {                
                
                PrinterSettings values;             
                values = myPrintDialog.PrinterSettings;
                myPrintDialog.Document = printDocument1;
                printDocument1.DefaultPageSettings.PaperSize = new PaperSize("drow cards" ,workField.Width+10 * (workField.Width/232), workField.Height+15);
                printDocument1.PrintPage += PrintPage;
                printDocument1.PrintController = new StandardPrintController();
                printDocument1.Print();
            }
            printDocument1.Dispose();

            for (int i = 0; i < elements.Count; i++)
            {
                if (elements[i].delete != null)
                    elements[i].delete.Show();
                elements[i].add.Show();
            }
        }

        private void PrintPage(object o, PrintPageEventArgs e)
        {
            image = new Bitmap(workField.Width, workField.Height);
            workField.DrawToBitmap(image, workField.ClientRectangle);      
            Point loc = new Point(0, 0);
            e.Graphics.DrawImage(image, loc);
        }

        private void cardsEdit_FormClosing(object sender, FormClosingEventArgs e)
        {
            main.Show();
        }
    }
}
