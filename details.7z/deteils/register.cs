﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.IO;

namespace deteils
{
    public partial class register : Form
    {
        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;
        private string encriptPass = "P@$$w0rd";
        private Login login;
        private string conectionString;
        private bool closing = false;

        public register(Login log, string conectionString)
        {
            InitializeComponent();

            this.Location = new Point(log.Location.X, log.Location.Y);
            login = log;
            this.conectionString = conectionString;
        }

        private void create_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conectionString);
            SqlDataAdapter da;
            DataTable usersDT = new DataTable();
            DataTable stat = new DataTable();

            con.Open();
            da = new SqlDataAdapter("select * from Users", con);
            da.Fill(usersDT);

            bool nameOwned = false;
            if (log.Text != "" && pass.Text != "")
            {
                for (int i = 0; i < usersDT.Rows.Count; i++)
                {
                    if (EncryptString(log.Text, encriptPass) == usersDT.Rows[i][1].ToString())
                    {
                        nameOwned = true;
                        break;
                    }
                }

                if (!nameOwned)
                {
                    int newID = 0;
                    for (int i = 0; i < usersDT.Rows.Count; i++)
                    {
                        if ((i + 1).ToString() != usersDT.Rows[i][0].ToString())
                        {
                            newID = i + 1;
                            break;
                        }
                    }
                    if (newID == 0)
                    {
                        usersDT.Rows.Add(usersDT.Rows.Count + 1);
                    }
                    else
                    {
                        usersDT.Rows.Add(newID);
                    }

                    int id = usersDT.Rows.Count - 1;

                    usersDT.Rows[id][1] = EncryptString(log.Text, encriptPass);
                    usersDT.Rows[id][2] = EncryptString(pass.Text, encriptPass);
                    usersDT.Rows[id][3] = false;

                    SqlCommandBuilder cb = new SqlCommandBuilder(da);
                    da.Update(usersDT);

                    da = new SqlDataAdapter("select * from statistic", con);
                    da.Fill(stat);

                    id = 1;
                    if (stat.Rows.Count != 0)
                    {
                        id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
                    }

                    stat.Rows.Add(id, log.Text, "Зарегистрирован", DateTime.Now);

                    cb = new SqlCommandBuilder(da);
                    da.Update(stat);

                    main main = new main(login, conectionString, log.Text, false);
                    main.Show();
                    closing = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Имя занято");
                }
            }
            else
            {
                MessageBox.Show("Поля не заполнены");
            }         

            con.Close();
        }

        public static string EncryptString(string plainText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        private void register_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!closing)
            login.Show();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
