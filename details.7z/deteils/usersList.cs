﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace deteils
{
    public partial class usersList : Form
    {
        private const string initVector = "pemgail9uzpgzl88";
        private const int keysize = 256;
        private string encriptPass = "P@$$w0rd";
        private string conectionString;
        private main main;
        private DataTable usersDT = new DataTable();       
        private SqlDataAdapter da;
        public usersList(main main)
        {

            InitializeComponent();

            this.Location = new Point(main.Location.X, main.Location.Y);
            this.main = main;
            this.conectionString = main.connectionString;                      

            SqlConnection con = new SqlConnection(conectionString);

            con.Open();
            da = new SqlDataAdapter("select * from users", con);
            da.Fill(usersDT);
            for (int i = 0; i < usersDT.Rows.Count; i++)
            {              
                usersDT.Rows[i][1] = DecryptString(usersDT.Rows[i][1].ToString(), encriptPass);
                usersDT.Rows[i][2] = DecryptString(usersDT.Rows[i][2].ToString(), encriptPass);                
            }

            users.DataSource = usersDT;

            users.Columns[1].HeaderText = "Логин";
            users.Columns[2].HeaderText = "Пароль";
            users.Columns[3].HeaderText = "Права администратора";

            con.Close();
        }

        public static string EncryptString(string plainText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();
            return Convert.ToBase64String(cipherTextBytes);
        }

        public static string DecryptString(string cipherText, string passPhrase)
        {
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
            byte[] keyBytes = password.GetBytes(keysize / 8);
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void add_Click(object sender, EventArgs e)
        {
            usersDT.Rows.Add();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if (users.CurrentCell.RowIndex != 0) usersDT.Rows.RemoveAt(users.CurrentCell.RowIndex);
        }

        private void usersList_FormClosing(object sender, FormClosingEventArgs e)
        {
            SqlConnection con = new SqlConnection(conectionString);
            DataTable updateUsers = new DataTable();
            con.Open();
            SqlCommandBuilder cb;

            da.Fill(updateUsers);
          

            string sql = "DELETE FROM Users";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
                        
            for (int i = 0; i < usersDT.Rows.Count; i++)
            {

                if (usersDT.Rows[i][0].ToString() != "" && usersDT.Rows[i][1].ToString() != "" && usersDT.Rows[i][2].ToString() != "")
                {
                    if(!String.IsNullOrEmpty(usersDT.Rows[i][3].ToString()))
                        updateUsers.Rows.Add(Convert.ToInt32(usersDT.Rows[i][0]), EncryptString(usersDT.Rows[i][1].ToString(), encriptPass), EncryptString(usersDT.Rows[i][2].ToString(), encriptPass), Convert.ToBoolean(usersDT.Rows[i][3]));
                    else
                        updateUsers.Rows.Add(Convert.ToInt32(usersDT.Rows[i][0]), EncryptString(usersDT.Rows[i][1].ToString(), encriptPass), EncryptString(usersDT.Rows[i][2].ToString(), encriptPass), false);
                }
            }
            cb = new SqlCommandBuilder(da);
            da.Update(updateUsers);

            DataTable stat = new DataTable();         
            da = new SqlDataAdapter("select * from statistic", con);
            
            da.Fill(stat);

            int id = 1;
            if (stat.Rows.Count != 0)
            {
                id = Convert.ToInt32(stat.Rows[stat.Rows.Count - 1][0]) + 1;
            }

            stat.Rows.Add(id, main.user, "Завершил работу с данными пользователей", DateTime.Now);

            cb = new SqlCommandBuilder(da);
            da.Update(stat);            

            con.Close();

            main.Enabled = true;
        }

        private void users_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            if (users.CurrentCell.RowIndex == 0 && users.CurrentCell.ColumnIndex == 1) usersDT.Rows[users.CurrentCell.RowIndex][users.CurrentCell.ColumnIndex] = "admin";
        }
    }
}
