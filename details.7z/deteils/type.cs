﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace deteils
{
    class type
    {
        public string name;
        public int maxTime;
        public string action;
        public bool used = false;
    }
   
}
